import React, { useState } from "react";

import Typist from "react-typist";
import TypistLoop from "react-typist-loop"

import "./TypicalText.css";

function TypicalText(props) {
  const { renderState, setRenderState, username, isLoggedIn, isGuest } = props;

  var message;
  /*Message being shown*/
  var content;
  /*Content to be returned by this function*/

  function originalMessageBuilder() {
    message = [
           'Green Curry',
           ' Laksa',
           ' Panini',
           ' Soup',
           ' Pasta',
           ' Garlic Bread',
           ' Apple Crumble',
           ' Banh Mi',
           ' Panini',
           ' Tilapia',
           ' Caesar Salad',
           ' Bacon and Eggs',
    ];
  }

  function thankYouMessageBuilder() {

    if (isLoggedIn && username != null) {
      message = "Welcome " + username + "!";
    } else {
      message = "Log in to access more features!";
    }
  }

  if (!(isLoggedIn && username != null) && !isGuest) {
    originalMessageBuilder();
    content = (
      <React.Fragment>
        <span className="TypicalTextStyle">
            Match yourself with some {" "}
           <TypistLoop interval={3000}>
               {message.map(text => <Typist key={text} startDelay={0}>{text}</Typist>)}
           </TypistLoop>
        </span>
      </React.Fragment>
    );
  } else {
    thankYouMessageBuilder();
    content = (
      <React.Fragment>
        <span className="TypicalTextStyle">
            <TypistLoop interval={1000}>
                {[message].map(text => <Typist key={text} startDelay={1000}>{text}</Typist>)}
            </TypistLoop>
        </span>
      </React.Fragment>
    );
  }
  return content;
}

export default TypicalText;
