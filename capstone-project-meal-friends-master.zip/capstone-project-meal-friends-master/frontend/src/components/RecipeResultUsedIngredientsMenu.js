import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Tooltip from "@material-ui/core/Tooltip";

import trashCan from "../images/trashCan.svg"; // NEED A GREEN TRASHCAN

const useStyles = makeStyles((theme) => ({
  menu: {},
}));

export default function RecipeResultUsedIngredientsMenu(props) {
  const classes = useStyles();
  const { tile, setAddIngredient } = props;
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
        aria-controls={tile.title + "menu"}
        aria-haspopup="true"
        onClick={handleClick}
        style={{ color: "#28bf4b", fontFamily: "CarmenSansRegular" }}
      >
        Show
      </Button>

      <Menu
        id={tile.title + "menu"}
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        className={classes.menu}
      >
        {tile.usedIngredients.map((ingredient) => {
          const labelId = `checkbox-list-label-${ingredient.name}`;
          return (
            <MenuItem key={ingredient.name} role={undefined}>
              <ListItemText
                id={ingredient.name + "label"}
                style={{ color: "#28bf4b", fontFamily: "CarmenSansRegular" }}
                primary={ingredient.name}
              />
            </MenuItem>
          );
        })}
      </Menu>
    </div>
  );
}

//                        <ListItemSecondaryAction>
//                            <Tooltip title="Remove this item from your virtual frdge if it has been used" placement="top" arrow >
//                                <IconButton onClick={() => removeHandler(ingredient)} edge="end" aria-label="remove">
//                                    <img src={trashCan}  style={{ width: '4vh'}} />
//                                    {/*Image source: https://www.flaticon.com/free-icon/trash-can_3159662?term=remove&page=1&position=7#*/}
//                                </IconButton>
//                            </Tooltip>
//                        </ListItemSecondaryAction>
