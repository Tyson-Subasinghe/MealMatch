import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Checkbox from "@material-ui/core/Checkbox";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListSubheader from "@material-ui/core/ListSubheader";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Collapse from "@material-ui/core/Collapse";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";

const useStyles = makeStyles((theme) => ({
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    borderRadius: "15px",
    "&$checked": {
      color: "#FFFFFF",
    },

    maxWidth: "18vmax",
    maxHeight: "85vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },

  checked: {},
}));

function RecipeFilters(props) {
  const {
    dietFilters,
    setDietFilters,
    cuisineFilters,
    setCuisineFilters,
    mealTypeFilters,
    setMealTypeFilters,
    recipes,
    setRecipes,
  } = props;
  const classes = useStyles();
  const [gotFilters, setGotFilters] = React.useState(false);
  const [dietOpen, setDietOpen] = React.useState(false);
  const [cuisineOpen, setCuisineOpen] = React.useState(false);
  const [mealTypeOpen, setMealTypeOpen] = React.useState(false);

  const handleClickDietOpen = () => {
    setDietOpen(!dietOpen);
  };

  const handleClickCuisineOpen = () => {
    setCuisineOpen(!cuisineOpen);
  };

  const handleClickMealTypeOpen = () => {
    setMealTypeOpen(!mealTypeOpen);
  };

  async function setFilters(r) {
    setDietFilters(r.diets);
    setCuisineFilters(r.cuisines);
    setMealTypeFilters(r.mealTypes);
  }

  {
    /* Function to select (deselected) filter, called when checkbox ticked */
  }
  async function selectFilter(filterNameToSelect, typeOfFilter) {
    let res = await fetch(
      "http://127.0.0.1:5000/api/recipe/filter/select?category=" +
        typeOfFilter +
        "&name=" +
        filterNameToSelect,
      {
        mode: "cors",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    let r = await res.json();
    setFilters(r);
  }

  {
    /* Function to deselect (selected) filter, called when checkbox unticked */
  }
  async function deselectFilter(filterNameToDeselect, typeOfFilter) {
    let res = await fetch(
      "http://127.0.0.1:5000/api/recipe/filter/deselect?category=" +
        typeOfFilter +
        "&name=" +
        filterNameToDeselect,
      {
        mode: "cors",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    let r = await res.json();
    setFilters(r);
  }

  {
    /* Function to get current filter data as a JSON objects */
  }
  async function getFilters(
    setDietFilters,
    setCuisineFilters,
    setMealTypeFilters
  ) {
    let res = await fetch("http://127.0.0.1:5000/api/recipe/filter/details", {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });

    let r = await res.json();
    setFilters(r);
  }

  {
    /* Update the search results only if a search has already been made */
  }
  async function getRecipes(recipes, setRecipes) {
    if (recipes == null) {
      return;
    }

    let res = await fetch("http://127.0.0.1:5000/api/recipe/search", {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });
    let r = await res.json();

    await setRecipes(r);
  }

  {
    /* When checkbox ticked/unticked */
  }
  async function selectHandler(filter, typeOfFilter) {
    if (filter.selected) {
      await deselectFilter(filter.name, typeOfFilter);
    } else {
      await selectFilter(filter.name, typeOfFilter);
    }
    // Refresh the search when a filter is updated
    getRecipes(recipes, setRecipes);
  }

  async function selectDietHandler(filter) {
    selectHandler(filter, "diets");
  }

  async function selectCuisineHandler(filter) {
    selectHandler(filter, "cuisines");
  }

  async function selectMealTypeHandler(filter) {
    selectHandler(filter, "mealTypes");
  }

  {
    /* Common logic for displaying filters as a list */
  }
  function mapFiltersToList(filtersToDisplay, selectFilterHandler) {
    return (
      <List component="div" disablePadding >
        {filtersToDisplay.map((filter) => {
          const labelId = `checkbox-list-label-${filter.name}`;
          return (
            <ListItem
              key={filter.name}
              role={undefined}
              dense
              button
              onClick={() => selectFilterHandler(filter)}
              style={{color: "#FFFFFF", fontFamily: "CarmenSansRegular"}}
            >
              <ListItemIcon>
                <Checkbox
                  edge="start"
                  checked={filter.selected}
                  classes={{
                    root: classes.root,
                    checked: classes.checked,
                  }}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </ListItemIcon>
              <span
                style={{ color: "#FFFFFF", fontFamily: "CarmenSansRegular", fontSize:"2vmin" }}
              >
                {filter.name}
              </span>
            </ListItem>
          );
        })}
      </List>
    );
  }

  {
    /* Get filter info if it hasn't been done already */
  }
  if (
    dietFilters == null ||
    cuisineFilters == null ||
    mealTypeFilters == null
  ) {
    if (gotFilters == false) {
      getFilters(setDietFilters, setCuisineFilters, setMealTypeFilters);
      setGotFilters(true);
    }
    return <div></div>;
  }

  return (
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      subheader={
        <ListSubheader
          component="div"
          id="nested-list-subheader"
          style={{
            color: "#FFFFFF",
            fontFamily: "CarmenSansHeavy",
            fontSize: "2vh",
          }}
        >

        <div style={{color: "#28BF4B", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin"}}>
            Recipe Filters
        </div>

        </ListSubheader>
      }
      className={classes.root}
      style={{ marginLeft: "0.5%" }}
    >
      <ListItem button onClick={handleClickDietOpen}>
        <ListItemText primary=<span  style={{ color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin" }}>
          Diets
        </span> />
        {dietOpen ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={dietOpen} timeout="auto" unmountOnExit>
        {mapFiltersToList(dietFilters, selectDietHandler)}
      </Collapse>

      <ListItem button onClick={handleClickCuisineOpen}>
        <ListItemText primary=
        <span  style={{ color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin" }}>
          Cuisines
        </span>
        />
        {cuisineOpen ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={cuisineOpen} timeout="auto" unmountOnExit>
        {mapFiltersToList(cuisineFilters, selectCuisineHandler)}
      </Collapse>

      <ListItem button onClick={handleClickMealTypeOpen}>
        <ListItemText primary=<span  style={{ color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin" }}>
          Meal Types
        </span> />
        {mealTypeOpen ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={mealTypeOpen} timeout="auto" unmountOnExit>
        {mapFiltersToList(mealTypeFilters, selectMealTypeHandler)}
      </Collapse>
    </List>
  );
}

export default RecipeFilters;
