import React, { Component } from "react";
import { GoogleLogin, GoogleLogout } from "react-google-login";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const CLIENT_ID =
  "1050549738006-6ml227scfha8rcdb1403of2shmhj34tl.apps.googleusercontent.com";
const styles = {
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    "&:hover": {
      background: "#34e35c",
      boxShadow: "0 3px 5px 2px rgba(255, 255, 255, 0.5)",
    },
    borderRadius: 10,
    border: 0,
    height: 60,
    padding: "0px 60px",
    boxShadow: "0 3px 5px 2px rgba(40, 191, 75, 0.5)",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",
  },
};

function Login(props) {
  const {
    classes,
    isLoggedIn,
    setIsLoggedIn,
    user,
    setUser,
    username,
    setUsername,
    setIsGuest,
    setScrolling,
    loadPastData,
  } = props;

  async function sendLogin(accessToken) {
    var data = await { token: accessToken };
    // alert(JSON.stringify(data));
    let res = await fetch("http://127.0.0.1:5000/api/user/login", {
      method: "POST",
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      redirect: "follow",
      referrerPolicy: "no-referrer",
      body: JSON.stringify(data),
    });
    let r = await res.json();
    setUser(r);
    setUsername(r.profile.username);
  }

  async function loginSuccess(response) {
    await setIsLoggedIn(true);
    console.log(response);
    await sendLogin(response.tokenId);
    // alert(response.tokenId)
    setIsGuest(false);
    setScrolling(true);
    // alert(response.accessToken);
    await loadPastData();
  }

  async function logoutSuccess(response) {
    setIsLoggedIn(false);
    // call logout route
    let res = await fetch("http://127.0.0.1:5000/api/user/logout", {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });
    await res.json();
    window.location.reload();
    return false;
  }

  async function loginFailure(response) {
    alert(
      "Failed to login. Please allow 3rd party cookies or allow accounts.google.com."
    );
  }

  async function logoutFailure(response) {
    setIsLoggedIn(false);
    alert("Failed to logout");
  }

  return isLoggedIn ? (
    <GoogleLogout
      clientId={CLIENT_ID}
      render={(renderProps) => (
        <Button
          onClick={renderProps.onClick}
          className={classes.root}
          style={styles}
        >
          <span className="ButtonText">{"Logout"}</span>
        </Button>
      )}
      onLogoutSuccess={logoutSuccess}
      onFailure={logoutFailure}
    />
  ) : (
    <GoogleLogin
      clientId={CLIENT_ID}
      render={(renderProps) => (
        <Button
          onClick={renderProps.onClick}
          className={classes.root}
          style={styles}
        >
          <span className="ButtonText">{"Login with Google"}</span>
        </Button>
      )}
      onSuccess={loginSuccess}
      onFailure={loginFailure}
      cookiePolicy={"single_host_origin"}
      responseType="code,token"
    />
  );
}

export default withStyles(styles)(Login);
