// import React from 'react';
import React, { useState, Component } from "react";
import { makeStyles } from "@material-ui/core/styles";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";

import RecipeResult from "./RecipeResult.js";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    overflow: "hidden",
  },
  gridList: {
    width: "80vw",
    height: "80vh",
    marginLeft: "20vw",
    backgroundColor: "#28bf4b",
    // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
    transform: "translateZ(0)",
    spacing: "3vmax",
  },
  titleBar: {
    color: "#28bf4b",
    fontFamily: "CarmenSansSemiBold",
    fontSize: "4vmin",
  },
  icon: {},
  gridListTile: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
  },
}));

{
  /*FOR NO BACKGROUND ON TEXT
    background:
  'linear-gradient(to bottom, rgba(40,191,75,0.0) 0%, ' +
  'rgba(40,191,75,0.0) 70%, rgba(40,191,75,0) 100%)',*/
}

export default function RecipeResultGridList(props) {
  const classes = useStyles();
  const {
    tileData,
    setScrolling,
    setAddIngredient,
    setShopIngredient,
    isLoggedIn,
  } = props;

  if (tileData == null) {
    return <div></div>;
  }

  return (
    <div
      className={classes.root}
      style={{ width: "80vw", height: "80vh", marginLeft: "20vw" }}
      // onMouseEnter={() => {setScrolling(false);}}
      // onMouseLeave={() => {setScrolling(true);}}
    >
      {/* Cell height in pixels to accommodate full size of results and spacing */}
      <GridList
        cellHeight={500}
        cols={3}
        spacing={0}
        className={classes.gridList}
      >
        {tileData.recipes.map((tile) => (
          <GridListTile
            key={tile.img}
            cols={1}
            rows={1}
            tile={classes.gridListTile}
          >
            <RecipeResult
              tile={tile}
              setAddIngredient={setAddIngredient}
              setShopIngredient={setShopIngredient}
              isLoggedIn={isLoggedIn}
            />
          </GridListTile>
        ))}
      </GridList>
    </div>
  );
}
