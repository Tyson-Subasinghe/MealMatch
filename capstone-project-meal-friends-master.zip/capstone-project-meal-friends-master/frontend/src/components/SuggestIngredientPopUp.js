import React from "react";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
import Typography from "@material-ui/core/Typography";
import Slide from "@material-ui/core/Slide";

import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import plus from "../images/plus.svg";
import minus from "../images/minus.svg";
import shoppingCartImage from "../images/shoppingCartImage.svg";

const MAP_KEY = "AIzaSyD-YQUHu-Fo7o2gre3zadUgDiOCs5WVpu0";
// When Suggest Ingredient button pressed, pop up slides up from bottom of page
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

// Called when "add" icon pressed; adds suggested ingredient to VF
async function addIngredient(ingredientToAdd, setAddIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/add?ingredient=" + ingredientToAdd,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var fridge = [];
  for (var i = 0; i < r.ingredients.length; i++) {
    await fridge.push(r.ingredients[i]);
  }
  setAddIngredient(fridge);
}

// Called when "exclude" icon pressed; adds suggested ingredient to exclusion list
async function excludeIngredient(ingredientToExclude, setExcludeIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/exclude/add?ingredient=" +
      ingredientToExclude,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var excludeFridge = [];
  for (var i = 0; i < r.excludedIngredients.length; i++) {
    await excludeFridge.push(r.excludedIngredients[i]);
  }
  setExcludeIngredient(excludeFridge);
}

// Called when "cart" icon pressed; adds suggested ingredient to shopping list
async function shopIngredient(ingredientToShop, setShopIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/shopping/add?ingredient=" +
      ingredientToShop,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var shoppingList = [];
  for (var i = 0; i < r.shoppingList.length; i++) {
    await shoppingList.push(r.shoppingList[i]);
  }
  setShopIngredient(shoppingList);
}

export default function SuggestIngredientPopUp(props) {
  const {
    suggestOpenState,
    setSuggestOpenState,
    suggestIngredient,
    setAddIngredient,
    setExcludeIngredient,
    setShopIngredient,
  } = props;

  const handleClose = () => {
    setSuggestOpenState(false);
  };

  var gridStyle = {
    position: "relative",
    float: "left",
    minHeight: "0px",
    overflow: "hidden",
    height: "100%",
  };

  // Adds suggested ingredient to VF, closes pop-up
  async function addHandler(ingredientToAdd) {
    addIngredient(ingredientToAdd, setAddIngredient);
    setSuggestOpenState(false);
  }

  // Adds suggested ingredient to exclusion list, closes pop-up
  async function excludeHandler(ingredientToExclude) {
    excludeIngredient(ingredientToExclude, setExcludeIngredient);
    setSuggestOpenState(false);
  }

  // Adds suggested ingredient to shopping list, closes pop-up
  async function cartHandler(ingredientToShop) {
    shopIngredient(ingredientToShop, setShopIngredient);
    setSuggestOpenState(false);
  }

  if (suggestIngredient == null) {
    return <div></div>;
  }

  // Displays suggested ingredient as a "tile" with the three action icons
  return (
    <Dialog
      onClose={handleClose}
      aria-labelledby="simple-dialog-title"
      open={suggestOpenState}
      TransitionComponent={Transition}
    >
      <DialogTitle>
        <div
          style={{
            fontSize: "3vmin",
            fontFamily: "CarmenSansSemiBold",
            color: "#28bf4b",
          }}
        >
          Do you have this ingredient?
        </div>
      </DialogTitle>

      <GridListTile key={suggestIngredient.name} style={gridStyle}>
        <div
          style={{
            textAlign: "center",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "5%",
          }}
        >
          <div
            style={{
              fontSize: "3vmin",
              fontFamily: "CarmenSansRegular",
              color: "#28bf4b",
            }}
          >
            {suggestIngredient.name}
          </div>

          <div style={{ marginTop: "2vh" }}>
            <img
              src={suggestIngredient.img}
              label={suggestIngredient.name}
              style={{ height: "18vh" }}
            />
          </div>
          <div style={{ marginTop: "1vh" }}>
            <Tooltip
              title="Add this ingredient to your Virtual Fridge to find recipes with it"
              placement="top"
              arrow
            >
              <IconButton onClick={() => addHandler(suggestIngredient.name)}>
                <img src={plus} style={{ width: "4vh" }} />
              </IconButton>
            </Tooltip>
            <Tooltip
              title="Add this ingredient to your Exclusion List to exclude recipes with it"
              placement="top"
              arrow
            >
              <IconButton onClick={() => excludeHandler(suggestIngredient.name)}>
                <img src={minus} style={{ width: "4vh" }} />
              </IconButton>
            </Tooltip>
            <Tooltip
              title="Add this ingredient to your Shopping List to find recipes with it"
              placement="top"
              arrow
            >
              <IconButton onClick={() => cartHandler(suggestIngredient.name)}>
                <img src={shoppingCartImage} style={{ width: "4vh" }} />
              </IconButton>
            </Tooltip>
          </div>
        </div>
      </GridListTile>
    </Dialog>
  );
}
