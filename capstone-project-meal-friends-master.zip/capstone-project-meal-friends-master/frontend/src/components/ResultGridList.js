import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";

import chili from "../images/chili.svg";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "space-around",
    overflow: "hidden",
    backgroundColor: theme.palette.background.paper,
  },
  gridList: {
    flexWrap: "nowrap",
    // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
    transform: "translateZ(0)",
  },
  title: {
    color: theme.palette.primary.light,
  },
  titleBar: {
    background:
      "linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)",
  },
}));

/**
 * The example data is structured as follows:
 *
 * import image from 'path/to/image.jpg';
 * [etc...]
 *
 * const tileData = [
 *   {
 *     img: image,
 *     title: 'Image',
 *     author: 'author',
 *   },
 *   {
 *     [etc...]
 *   },
 * ];
 */

export default function IngredientResultGridList(props) {
  const classes = useStyles();
  const { tileData, setInput, setTileData, setScrolling } = props;

  async function addIngredient(ingredientToAdd) {
    let res = await fetch(
      "http://127.0.0.1:5000/api/ingredient/add?ingredient=" + ingredientToAdd,
      {
        mode: "cors",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    let r = await res.json();
    var fridge = "";
    for (var i = 0; i < r.ingredients.length; i++) {
      fridge += r.ingredients[i].name + ", ";
    }
    alert("Fridge: " + fridge);
    setInput("");
    setTileData(null);
  }

  async function clickHandler(ingredientName) {
    addIngredient(ingredientName);
    setScrolling(true);
  }

  if (tileData == null) {
    return <div></div>;
  }
  return (
    <div
      className={classes.root}
      onMouseEnter={() => {
        setScrolling(false);
      }}
      onMouseLeave={() => {
        setScrolling(true);
      }}
    >
      <GridList className={classes.gridList} cols={3}>
        {tileData.map((tile) => (
          <GridListTile key={tile.name}>
            <img src={tile.img} alt={tile.name} />
            <Button
              onClick={() => clickHandler(tile.name)}
              style={{ marginTop: "10%" }}
            >
              <span className="ButtonText"> Add Ingredient</span>
            </Button>
          </GridListTile>
        ))}
      </GridList>
    </div>
  );
}
