import React from "react";

const MAP_KEY = "AIzaSyD-YQUHu-Fo7o2gre3zadUgDiOCs5WVpu0";

export default function NearbyStores(props) {
  const { width, height } = props;
  return (
    <iframe
      width={width}
      height={height}
      frameborder="0"
      src={
        "https://www.google.com/maps/embed/v1/search?key=" +
        MAP_KEY +
        "&q=supermarkets"
      }
      allowfullscreen
    ></iframe>
  );
}
