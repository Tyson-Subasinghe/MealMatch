import React, { useState, useEffect } from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const styles = {
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    "&:hover": {
      background: "#34e35c",
      boxShadow: "0 3px 5px 2px rgba(255, 255, 255, 0.5)",
    },
    borderRadius: 10,
    border: 0,
    height: 60,
    padding: "0px 60px",
    boxShadow: "0 3px 5px 2px rgba(40, 191, 75, 0.5)",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",
  },
};

function NearbyStoresButton(props) {
  const { classes, setNearbyStoresOpenState} = props;

  const handleClickOpen = () => {
    setNearbyStoresOpenState(true);
  };

  return (
    <Button onClick={handleClickOpen} className={classes.root}>
      <span className="ButtonText"> Stores near you</span>
    </Button>
  );
}

export default withStyles(styles)(NearbyStoresButton);
