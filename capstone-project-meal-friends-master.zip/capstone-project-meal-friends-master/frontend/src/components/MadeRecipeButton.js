import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Checkbox from "@material-ui/core/Checkbox";
import Tooltip from "@material-ui/core/Tooltip";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
import CloseIcon from "@material-ui/icons/Close";
import tick from "../images/tick.svg";
import tickLocked from "../images/tickLocked.svg";

const useStyles = makeStyles((theme) => ({
  root: {

    color: "#28bf4b",
    borderRadius: "15px",
    "&$checked": {
      color: "#28bf4b",
    },

    width: "85%",
    maxWidth: "50vmax",
    maxHeight: "85vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },
  checked:{},

  button:{
      background: "#28bf4b",
      color: "#FFFFFF",
      "&:hover": {
        background: "#34e35c",
        borderRadius: 15,
        border: 0,

      },
      borderRadius: 15,
      border: 0,
      height: 60,
      width: "30vw",
      marginLeft:"2.8vw",
      marginBottom:"1vw",
      padding: "10px 10px 10px 10px",
      textTransform: "None",
      fontFamily: "CarmenSansSemiBold",
  }
}));

async function removeIngredient(ingredientsToRemove, setAddIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/remove?ingredient=" +
      ingredientsToRemove,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var fridge = [];
  for (var i = 0; i < r.ingredients.length; i++) {
    await fridge.push(r.ingredients[i]);
  }
  setAddIngredient(fridge);
}

function MadeRecipePopUp(props) {
  const classes = useStyles();
  const { tile, open, onClose, setAddIngredient } = props;
  const [checked, setChecked] = React.useState([]);

  const handleClose = () => {
    onClose();
  };

  async function removeHandler() {
    removeIngredient(checked.toString(), setAddIngredient);
    onClose();
  }

  const selectHandler = (ingredient) => () => {
    const currentIndex = checked.indexOf(ingredient);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(ingredient);
    } else {
      newChecked.splice(currentIndex, 1);
    }
    setChecked(newChecked);
  };

  return (

    <Dialog
      onClose={handleClose}
      aria-labelledby="simple-dialog-title"
      open={open}
    >

      <DialogTitle id="simple-dialog-title">


        <span style={{ fontFamily: "CarmenSansSemiBold", fontSize: '3vmin' }}>
          {"Which ingredients have you used up?"}
        </span>



      </DialogTitle>

      <List>
        {tile.usedIngredients.map((ingredient) => (
          <ListItem
            button
            onClick={selectHandler(ingredient.name)}
            role={undefined}
            key={ingredient.name}
          >
            <ListItemIcon>
              <Checkbox
                edge="start"
                checked={checked.indexOf(ingredient.name) !== -1}
                tabIndex={-1}
                disableRipple
                classes={{
                  root: classes.root,
                  checked: classes.checked,
                }}
              />
            </ListItemIcon>
            <span style={{ fontFamily: "CarmenSansRegular" }}>
              {ingredient.name}
            </span>
          </ListItem>
        ))}
      </List>

      <Button
        variant="outlined"
        color="primary"
        onClick={() => removeHandler()}
        classes={{
          root: classes.button,
        }}
      >

        <span style={{ fontFamily: "CarmenSansSemiBold", fontSize: '3vmin', transform:'none', textTransform:'none' }}>
          {"Remove from Virtual Fridge"}
        </span>
      </Button>
    </Dialog>
  );
}

export default function MadeRecipeButton(props) {
  const [open, setOpen] = React.useState(false);
  const { tile, setAddIngredient, isLoggedIn } = props;

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  if (isLoggedIn) {
    return (
      <div>
        <Tooltip title="Mark recipe as completed" placement="top" arrow>
          <IconButton onClick={handleClickOpen}>
            <img
              src={tick}
              alt={"Check items off from list"}
              style={{ width: "2vmin" }}
            />
          </IconButton>
        </Tooltip>
        <MadeRecipePopUp
          tile={tile}
          open={open}
          onClose={handleClose}
          setAddIngredient={setAddIngredient}
        />
      </div>
    );
  }

  return (
    <div>
      <Tooltip title="Please login to use this feature" placement="top" arrow>
        <IconButton>
        <img
          src={tickLocked}
          alt={"Check items off from list"}
          style={{ width: "2vmin" }}
        />
        </IconButton>
      </Tooltip>
    </div>
  );
}
