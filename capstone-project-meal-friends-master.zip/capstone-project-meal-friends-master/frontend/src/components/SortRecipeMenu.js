import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import MenuItem from "@material-ui/core/MenuItem";
import Menu from "@material-ui/core/Menu";
import Grow from "@material-ui/core/Grow";
import Popper from "@material-ui/core/Popper";

const useStyles = makeStyles((theme) => ({
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    borderRadius: "15px",
    "&$checked": {
      color: "#FFFFFF",
    },

    maxWidth: "18vmax",
    maxHeight: "85vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },

  checked: {},
}));

const options = ["Missing ingredients", "Matching ingredients", "Cooking time"];

async function sortRecipes(recipes, setRecipes, sortType, sortOrder) {
  if (recipes == null) {
    return;
  }

  let res = await fetch(
    "http://127.0.0.1:5000/api/recipe/search?sort=" +
      sortType +
      "&order=" +
      sortOrder,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();

  await setRecipes(r);
}

export default function SortRecipeMenu(props) {
  const classes = useStyles();
  const { recipes, setRecipes, sortType, setSortType, sortAscending } = props;
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [selectedIndex, setSelectedIndex] = React.useState(0);

  const handleClickListItem = (event) => {
    setAnchorEl(event.currentTarget);
  };

  React.useEffect(() => {
    if (sortAscending) {
      var sortOrder = "ascending";
    } else {
      var sortOrder = "descending";
    }
    sortRecipes(recipes, setRecipes, sortType, sortOrder);
  }, [sortType]);

  const handleMenuItemClick = (event, index) => {
    setSelectedIndex(index);

    if (index == 0) {
      setSortType("missedIngredientCount");
    } else if (index == 1) {
      setSortType("usedIngredientCount");
    } else {
      setSortType("readyInMinutes");
    }

    setAnchorEl(null);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div className={classes.root} style={{marginLeft:'0.7%'}}>
      <List component="nav" aria-label="Sort by">
        <ListItem
          button
          aria-haspopup="true"
          aria-controls={Boolean(anchorEl) ? "menu-list-grow" : undefined}
          aria-label="Sort by"
          onClick={handleClickListItem}
        >
          <ListItemText primary={
              <div style={{color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin"}}>
                    Sort by
              </div>}
          secondary={
              <div style={{color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"2vmin"}}>
                  {options[selectedIndex]}
              </div>
          }
               />
        </ListItem>
      </List>
      <Menu
        id="lock-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        getContentAnchorEl={null}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        transformOrigin={{ vertical: "top", horizontal: "left" }}
      >
        {options.map((option, index) => (
          <MenuItem
            key={option}
            selected={index === selectedIndex}
            onClick={(event) => handleMenuItemClick(event, index)}
          >
          <div style={{color: "#28BF4B", fontFamily: "CarmenSansSemiBold", fontSize:"2vmin"}}>
                {option}
          </div>
          </MenuItem>
        ))}
      </Menu>
    </div>
  );
}

export { sortRecipes };
