import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import RegisterUsernameButton from "./RegisterUsernameButton.js";

const useStyles = makeStyles((theme) => ({
  root: {
    "& label": {
      fontFamily: "CarmenSansSemiBold",
      color: "white",
      fontSize: "20px",
    },
    "& .MuiTextField-root": {
      margin: theme.spacing(1),
      width: "50ch",
      color: "#28bf4b",
      fontFamily: "CarmenSansSemiBold",

      background: "#28bf4b",
      opacity: "85%",
      color: "#FFFFFF",
      "&:hover": {
        background: "#34e35c",
      },
      borderRadius: 5,
      border: 0,

      textTransform: "None",
      fontFamily: "CarmenSansSemiBold",

      "& label.Mui-focused": {
        color: "white",
        fontFamily: "CarmenSansHeavy",
      },
      "& .MuiOutlinedInput-root": {
        "& fieldset": {
          borderColor: "#28bf4b",
        },
      },
    },
  },
}));

export default function InputForm(props) {
  const classes = useStyles();

  const { input, setInput, text, setSearchIngredient, setUsername } = props;

  async function getSearchIngredient() {
    let res = await fetch(
      "http://127.0.0.1:5000/api/ingredient/search?ingredient=" + input,
      {
        mode: "cors",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    let r = await res.json();

    await setSearchIngredient(r.ingredients);
  }

  async function registerUsername() {
    // let res = await fetch('http://127.0.0.1:5000/api/ingredient/search?ingredient='+input, {mode: 'cors', credentials:'include', headers: {
    //   'Content-Type': 'application/json'
    // }});
    // let r = await res.json();
    // if (r == false) { <div> Username is taken. </div>}
    await setUsername(input);
  }

  const handleChangeName = (event) => {
    {
      /*
           2. Make sure length is <50
      */
    }
    if (event.target.value.toString().length > 50) {
      return;
    }

    setInput(event.target.value);
  };

  return (
    <form className={classes.root} noValidate autoComplete="off">
      <div>
        <TextField
          label={text}
          value={input}
          onKeyDown={(e) => {
            if (e.keyCode == 13 && setSearchIngredient != null) {
              e.preventDefault();
              getSearchIngredient();
            } else if (e.keyCode == 13 && setUsername != null) {
              e.preventDefault();
              registerUsername();
            }
          }}
          onChange={handleChangeName}
          variant="outlined"
        />
      </div>
    </form>
  );
}
