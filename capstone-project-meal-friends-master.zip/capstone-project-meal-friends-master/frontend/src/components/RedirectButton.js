import React, { useState } from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const styles = {
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    "&:hover": {
      background: "#34e35c",
      boxShadow: "0 3px 5px 2px rgba(255, 255, 255, 0.5)",
    },
    borderRadius: 10,
    border: 0,
    height: 60,
    padding: "0px 60px",
    boxShadow: "0 3px 5px 2px rgba(40, 191, 75, 0.5)",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",

  },
};

function RedirectButton(props) {
  const { classes, disabled, scrollTo, scrollToWhere, text, styles } = props;
  const clickHandler = (input) => {
    scrollTo(scrollToWhere);
  };

  var content;

  content = (
    <Button
      disabled={disabled}
      onClick={clickHandler.bind()}
      className={classes.root}
      style={styles}
    >
      <span className="ButtonText">{text}</span>
    </Button>
  );

  return content;
}

export default withStyles(styles)(RedirectButton);
