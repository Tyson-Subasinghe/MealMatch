import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import VirtualFridge from "./VirtualFridge.js";

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    background: "#28bf4b",
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
}));

export default function IngredientRemovalPopUp(props) {
  const classes = useStyles();
  const { addIngredient, setAddIngredient } = props;
  const [open, setOpen] = React.useState(true);

  {
    /* Close the PopUp when close button pressed */
  }
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  {
    /* Prompts PopUp whenever new ingredient added to VF */
  }
  React.useEffect(() => {
    setOpen(true);
  }, [addIngredient]);

  if (addIngredient == null) {
    return <div></div>;
  }

  {
    /* Main code for PopUp*/
  }
  return (
    <div className={classes.root}>
      <Snackbar open={open} autoHideDuration={3000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="success">
          <span style={{ color: "#FFFFFF", fontFamily: "CarmenSansRegular" }}>
            Removed from VirtualFridge!
          </span>
        </Alert>
      </Snackbar>
    </div>
  );
}
