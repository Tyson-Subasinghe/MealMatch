import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import visit from "../images/visit.svg";
import RecipeResultMissingIngredientsMenu from "./RecipeResultMissingIngredientsMenu";
import RecipeResultUsedIngredientsMenu from "./RecipeResultUsedIngredientsMenu";
import MadeRecipeButton from "./MadeRecipeButton";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(2),
    background: "#FFFFFF",
    margin: "auto",
    maxWidth: "18vmax",
    borderRadius: 25,
  },
  imgPaper: {
    alignContent: "center",
    padding: theme.spacing(2),
    margin: "auto",
    color: "#EEEEEE",
  },
  image: {
    width: "16vmax",
    height: "12vmax",
  },
  titleBar: {
    color: "#28bf4b",
    fontFamily: "CarmenSansSemiBold",
    fontSize: "2vmin",
  },
}));

export default function RecipeResult(props) {
  {
    /* A recipe result displays on a card.
    Link button will open the linked recipe in a new tab.
    Matching ingredients and missing ingredients display the number of their category and open menus which allow further action on these ingredients. */
  }
  const classes = useStyles();
  const { tile, setAddIngredient, setShopIngredient, isLoggedIn } = props;

  const handleMissingIngredient = () => {};

  return (
    <div className={classes.root}>
      {/* Manual padding */}
      <Grid container spacing={0} direction="column">
        {/* Result card */}
        <Grid
          container
          item
          spacing={0}
          xs={8}
          justify="flex-start"
          alignItems="center"
        >
          <Paper className={classes.paper} elevation={0}>
            {/* Title - also link to external recipe page*/}
            <Grid container wrap="nowrap" spacing={2} alignItems="center">
              <Tooltip title={tile.title} placement="top" arrow>
                <Grid
                  item
                  xs
                  zeroMinWidth
                  onClick={(e) => {
                    e.preventDefault();
                    window.open(tile.sourceUrl, "newwindow");
                  }}
                >
                  <Typography noWrap className={classes.titleBar}>
                    {tile.title}
                  </Typography>
                </Grid>
              </Tooltip>
              <Grid item>
                <MadeRecipeButton
                  key={tile.title}
                  tile={tile}
                  setAddIngredient={setAddIngredient}
                  isLoggedIn={isLoggedIn}
                  />
              </Grid>
              <Grid item>
                <IconButton
                  aria-label={` ${tile.title}`}
                  className={classes.icon}
                  spacing={0}
                >
                  <img
                    src={visit}
                    alt={"Visit website"}
                    style={{ width: "2vmin" }}
                    spacing={0}
                    onClick={(e) => {
                      e.preventDefault();
                      window.open(tile.sourceUrl, "newwindow");
                    }}
                  />
                </IconButton>
              </Grid>
            </Grid>

            {/* Prep time */}
            <Grid item spacing={2} xs={12} alignItems="flex-start">
              <Typography variant="body2" gutterBottom>
                <div style = {{color: '#000000', fontSize:'1vw', fontFamily:'CarmenSansRegular'}}>

                {"Time required: " + tile.readyInMinutes + " mins"}

                </div>

              </Typography>
            </Grid>

            {/* Image - also link to external recipe page*/}
            <Grid item>
              <Paper className={classes.imgPaper}>
                <img
                  src={tile.image}
                  alt={tile.title}
                  className={classes.image}
                  onClick={(e) => {
                    e.preventDefault();
                    window.open(tile.sourceUrl, "newwindow");
                  }}
                />
              </Paper>
            </Grid>

            {/* Matching ingredients  */}
            <Grid item spacing={2} xs={12}>
              <Grid
                container
                wrap="nowrap"
                spacing={2}
                justify="space-between"
                alignItems="center"
              >
                <Grid item xs>
                  <Typography>

                    <div style = {{color: '#000000', fontSize:'1vw', fontFamily:'CarmenSansRegular'}}> Matching ingredients: {tile.usedIngredientCount} </div>
                  </Typography>
                </Grid>
                <Grid item>
                  <RecipeResultUsedIngredientsMenu
                    key={tile.title}
                    tile={tile}
                    setAddIngredient={setAddIngredient}
                  />
                </Grid>
              </Grid>
            </Grid>

            {/* Missing ingredients  */}
            <Grid item spacing={2} xs={12}>
              <Grid
                container
                wrap="nowrap"
                spacing={2}
                justify="space-between"
                alignItems="center"
              >
                <Grid item xs>
                  <Typography>

                    <div style = {{color: '#000000', fontSize:'1vw', fontFamily:'CarmenSansRegular'}}> Missing ingredients: {tile.missedIngredientCount} </div>
                  </Typography>
                </Grid>
                <Grid item>
                  <RecipeResultMissingIngredientsMenu
                    key={tile.title}
                    tile={tile}
                    setShopIngredient={setShopIngredient}
                  />
                </Grid>
              </Grid>
            </Grid>

            {/* Made recipe button  */}
            <Grid item spacing={0} xs={12}>
              <Grid
                container
                wrap="nowrap"
                spacing={2}
                justify="space-between"
                alignItems="center"
              >

              </Grid>
            </Grid>
          </Paper>
        </Grid>
        <Grid item xs={4}>
          {/* Right side padding */}
        </Grid>
      </Grid>
    </div>
  );
}
