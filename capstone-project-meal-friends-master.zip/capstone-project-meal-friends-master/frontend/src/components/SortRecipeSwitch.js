import React, { useEffect } from "react";
import { withStyles } from "@material-ui/core/styles";
import { makeStyles } from "@material-ui/core/styles";
import { purple } from "@material-ui/core/colors";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { sortRecipes } from "./SortRecipeMenu.js";

const AntSwitch = withStyles((theme) => ({
  root: {
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
    marginBottom: '3px',
  },
  switchBase: {
    padding: 2,
    color: '#28BF4B',
    "&$checked": {
      transform: "translateX(12px)",
      color: theme.palette.common.white,
      "& + $track": {
        opacity: 1,
        backgroundColor: '#28BF4B',
        borderColor: '#FFFFFF',
      },
    },
  },
  thumb: {
    width: 15,
    height: 15,
    boxShadow: "none",

  },
  track: {
    border: `1px solid #28BF4B`,
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor: theme.palette.common.white,

  },
  checked: {},
}))(Switch);

export default function SortRecipeSwitch(props) {
  const {
    recipes,
    setRecipes,
    sortType,
    sortAscending,
    setSortAscending,
  } = props;

  React.useEffect(() => {
    if (sortAscending) {
      var sortOrder = "ascending";
    } else {
      var sortOrder = "descending";
    }
    sortRecipes(recipes, setRecipes, sortType, sortOrder);
  }, [sortAscending]);

  const handleChange = (event) => {
    setSortAscending(!sortAscending);
  };

  return (
    <FormGroup style={{marginLeft:'1.7%', marginTop: '3%'}}>
      <Typography component="div">
        <Grid component="label" container alignItems="center" spacing={1}>
          <Grid item>
              <div style={{color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin"}}>
                    Asc
              </div>
          </Grid>
          <Grid item>
            <AntSwitch checked={!sortAscending} onChange={handleChange} />
          </Grid>
          <Grid item>
              <div style={{color: "#FFFFFF", fontFamily: "CarmenSansSemiBold", fontSize:"3vmin"}}>
                    Desc
              </div>
          </Grid>
        </Grid>
      </Typography>
    </FormGroup>
  );
}
