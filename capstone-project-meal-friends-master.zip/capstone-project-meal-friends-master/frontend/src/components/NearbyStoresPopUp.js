import React from "react";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
import Typography from "@material-ui/core/Typography";
import Slide from "@material-ui/core/Slide";

import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import plus from "../images/plus.svg";
import minus from "../images/minus.svg";
import shoppingCartImage from "../images/shoppingCartImage.svg";

const MAP_KEY = "AIzaSyD-YQUHu-Fo7o2gre3zadUgDiOCs5WVpu0";


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function NearbyStoresPopUp(props) {
  const {
    nearbyStoresOpenState,
    setNearbyStoresOpenState,
  } = props;

  const handleClose = () => {
    setNearbyStoresOpenState(false);
  };

  var gridStyle = {
    position: "relative",
    float: "left",
    minHeight: "0px",
    overflow: "hidden",
    height: "100%",
  };



  // Displays pop up
  return (
    <Dialog
      onClose={handleClose}
      aria-labelledby="simple-dialog-title"
      open={nearbyStoresOpenState}
      TransitionComponent={Transition}
    >
      <DialogTitle id="simple-dialog-title">
        <div style={{fontFamily:"CarmenSansSemiBold", color:"#28bf4b", fontSize:"3vmin"}}>
            Here are some stores near you
        </div>
      </DialogTitle>

      <iframe
        width={1000}
        height={700}
        frameborder="0"
        src={
          "https://www.google.com/maps/embed/v1/search?key=" +
          MAP_KEY +
          "&q=supermarkets"
        }
        allowfullscreen
      ></iframe>
    </Dialog>
  );
}
