import React, { useState, useEffect } from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const styles = {
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    "&:hover": {
      background: "#34e35c",
      boxShadow: "0 3px 5px 2px rgba(255, 255, 255, 0.5)",
    },
    borderRadius: 10,
    border: 0,
    height: 60,
    padding: "0px 60px",
    boxShadow: "0 3px 5px 2px rgba(40, 191, 75, 0.5)",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",
  },
};

function SuggestIngredientButton(props) {
  const { classes, setSuggestOpenState, setSuggestIngredient } = props;

  const handleClickOpen = () => {
    getIngredientSuggestion();
    setSuggestOpenState(true);
  };

  async function getIngredientSuggestion() {
    let res = await fetch("http://127.0.0.1:5000/api/ingredient/suggestion", {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });
    let r = await res.json();
    setSuggestIngredient(r.ingredientSuggestion);
  }

  return (
    <Button onClick={handleClickOpen} className={classes.root}>
      <span className="ButtonText"> Suggest Ingredient</span>
    </Button>
  );
}

export default withStyles(styles)(SuggestIngredientButton);
