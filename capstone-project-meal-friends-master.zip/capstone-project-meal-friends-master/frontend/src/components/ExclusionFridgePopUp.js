import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import ExclusionFridge from "./ExclusionFridge.js";

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
}));

export default function ExclusionFridgePopUp(props) {
  const classes = useStyles();
  const { excludeIngredient, setExcludeIngredient } = props;
  const [open, setOpen] = React.useState(true);

  {
    /* Close the PopUp when close button pressed */
  }
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  {
    /* Prompts PopUp whenever new ingredient added to EF */
  }
  React.useEffect(() => {
    setOpen(true);
  }, [excludeIngredient]);

  if (excludeIngredient == null) {
    return <div></div>;
  }

  {
    /* Main code for PopUp*/
  }
  return (
    <div className={classes.root}>
      <Snackbar open={open} autoHideDuration={5000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="success">
          Added to Exclusion List!
        </Alert>
      </Snackbar>
    </div>
  );
}
