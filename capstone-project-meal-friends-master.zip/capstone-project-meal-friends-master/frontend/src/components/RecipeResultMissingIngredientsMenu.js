import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Tooltip from "@material-ui/core/Tooltip";

import shoppingCartImage from "../images/shoppingCartImage.svg";

const useStyles = makeStyles((theme) => ({
  menu: {},
}));

async function shopIngredient(ingredientToShop, setShopIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/shopping/add?ingredient=" +
      ingredientToShop,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var shoppingList = [];
  for (var i = 0; i < r.shoppingList.length; i++) {
    await shoppingList.push(r.shoppingList[i]);
  }
  setShopIngredient(shoppingList);
}

export default function RecipeResultMissingIngredientsMenu(props) {
  const classes = useStyles();
  const { tile, setShopIngredient } = props;
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  async function cartHandler(ingredientToShop) {
    shopIngredient(ingredientToShop, setShopIngredient);
    handleClose();
  }

  return (
    <div>
      <Button
        aria-controls={tile.title + "menu"}
        aria-haspopup="true"
        onClick={handleClick}
        style={{ color: "#28bf4b", fontFamily: "CarmenSansRegular" }}
      >
        Show
      </Button>

      <Menu
        id={tile.title + "menu"}
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        className={classes.menu}
      >
        {tile.missedIngredients.map((ingredient) => {
          const labelId = `checkbox-list-label-${ingredient.name}`;
          return (
            <MenuItem key={ingredient.name} role={undefined}>
              <ListItemText
                id={ingredient.name + "label"}
                style={{ color: "#28bf4b", fontFamily: "CarmenSansRegular" }}
                primary={ingredient.name}
              />
              <ListItemSecondaryAction>
                <Tooltip
                  title="Add this ingredient to your shopping cart to find recipes with it"
                  placement="top"
                  arrow
                >
                  <IconButton
                    onClick={() => cartHandler(ingredient.name)}
                    edge="end"
                  >
                    <img src={shoppingCartImage} style={{ width: "3vh" }} />
                  </IconButton>
                </Tooltip>
              </ListItemSecondaryAction>
            </MenuItem>
          );
        })}
      </Menu>
    </div>
  );
}
