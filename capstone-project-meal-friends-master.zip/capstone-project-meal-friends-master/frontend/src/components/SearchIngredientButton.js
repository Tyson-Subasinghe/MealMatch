import React, { useState, useEffect } from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const styles = {
  root: {
    background: "#28bf4b",
    color: "#FFFFFF",
    "&:hover": {
      background: "#34e35c",
      boxShadow: "0 3px 5px 2px rgba(255, 255, 255, 0.5)",
    },
    borderRadius: 10,
    border: 0,
    height: 60,
    padding: "0px 60px",
    boxShadow: "0 3px 5px 2px rgba(40, 191, 75, 0.5)",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",
  },
};

function SearchIngredientButton(props) {
  const { classes, input, setInput, setSearchIngredient } = props;

  // When button is clicked, generates ingredient to suggest based on already entered ingredients
  async function getSearchIngredient() {
    let res = await fetch(
      "http://127.0.0.1:5000/api/ingredient/search?ingredient=" + input,
      {
        mode: "cors",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    let r = await res.json();

    await setSearchIngredient(r.ingredients);
  }

  async function clickHandler() {
    getSearchIngredient();
  }

  return (
    <Button onClick={clickHandler.bind()} className={classes.root}>
      <span className="ButtonText"> Search Ingredient</span>
    </Button>
  );
}

export default withStyles(styles)(SearchIngredientButton);
