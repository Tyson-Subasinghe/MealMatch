import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";


function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
}));

export default function EmailSentPopUp(props) {
  const classes = useStyles();
  const { sendEmail, setSendEmail } = props;
  const [open, setOpen] = React.useState(true);

  {
    /* Close the PopUp when close button pressed */
  }
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setSendEmail(null);
    setOpen(false);
  };

  {
    /* Prompts PopUp whenever new ingredient added to VF */
  }
  React.useEffect(() => {
    setOpen(true);
  }, [sendEmail]);

  if (sendEmail == null) {
    return <div></div>;
  }

  {
    /* Main code for PopUp*/
  }
  return (
    <div className={classes.root}>
      <Snackbar open={open} autoHideDuration={2000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="success">
          <span style={{ color: "#FFFFFF", fontFamily: "CarmenSansRegular" }}>
            {sendEmail}
          </span>
        </Alert>
      </Snackbar>
    </div>
  );
}
