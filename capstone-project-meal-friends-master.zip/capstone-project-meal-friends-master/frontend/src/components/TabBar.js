import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import { makeStyles } from "@material-ui/core/styles";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    justifyContent: "center",
    overflow: "hidden",
    background: "#28bf4b",
  },
  gridList: {
    flexWrap: "nowrap",
    transform: "translateZ(0)",
    height: "60px",
  },
  title: {
    color: theme.palette.primary.light,
  },
  titleBar: {
    background:
      "linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)",
  },
  button: {
    background: "rgba(255, 255, 255, 0)",
    color: "#FFFFFF",
    "&:hover": {
      background: "rgba(0, 0, 0, 0.1)",
    },
    height: 60,
    border: 0,
    borderRadius: 0,
    width: "25vw",
    padding: "0px 0px",
    boxShadow: "rgba(255, 255, 255, 0)",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",
  },
}));

// Add Recipe Search functionality to "Recipe Search" tab - automatically generates recipe results (with default filters) on clicking the tab
async function getRecipes(setRecipes) {
  let res = await fetch("http://127.0.0.1:5000/api/recipe/search", {
    mode: "cors",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });
  let r = await res.json();

  await setRecipes(r);
}

export default function TabBar(props) {
  const {
    isLoggedIn,
    setIsLoggedIn,
    setScrolling,
    scrollTo,
    scrolling,
    isGuest,
    setRecipes,
  } = props;

  const classes = useStyles();

  async function redirectSearchIngredient() {
    scrollTo(1);
  }

  const handleRecipeSearch = () => {
    getRecipes(setRecipes);
    scrollTo(3);
  };

  var homePageTab = {
    button: (
      <Button
        disabled={!(isLoggedIn || isGuest)}
        onClick={() => {
          scrollTo(0);
        }}
        className={classes.button}
      >
        <span className="ButtonText">{"Home Page"}</span>
      </Button>
    ),
  };

  var searchIngredientTab = {
    button: (
      <Button
        disabled={!(isLoggedIn || isGuest)}
        onClick={() => {
          scrollTo(1);
        }}
        className={classes.button}
      >
        <span className="ButtonText">{"Ingredient Search"}</span>
      </Button>
    ),
  };

  var virtualFridgeTab = {
    button: (
      <Button
        disabled={!(isLoggedIn || isGuest)}
        onClick={() => {
          scrollTo(2);
        }}
        className={classes.button}
      >
        <span className="ButtonText">{"Virtual Fridge"}</span>
      </Button>
    ),
  };

  var recipeSearchTab = {
    button: (
      <Button
        disabled={!(isLoggedIn || isGuest)}
        onClick={handleRecipeSearch}
        className={classes.button}
      >
        <span className="ButtonText">{"Recipe Search"}</span>
      </Button>
    ),
  };

  var tileData = [
    homePageTab,
    searchIngredientTab,
    virtualFridgeTab,
    recipeSearchTab,
  ];

  return (
    <div
      className={classes.root}
      onMouseEnter={() => {
        setScrolling(false);
      }}
      onMouseLeave={() => {
        setScrolling(true);
      }}
    >
      <GridList className={classes.gridList} cols={4}>
        {tileData.map((tile) => (
          <GridListTile key={tile}>{tile.button}</GridListTile>
        ))}
      </GridList>
    </div>
  );
}
