import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListSubheader from "@material-ui/core/ListSubheader";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import IconButton from "@material-ui/core/IconButton";
import Checkbox from "@material-ui/core/Checkbox";
import Tooltip from "@material-ui/core/Tooltip";
import trashCan from "../images/trashCan.svg";

const useStyles = makeStyles((theme) => ({
  rootHeader: {
    background: "#28bf4b",
    color: "#FFFFFF",
    borderRadius: "15px",
    borderBottomLeftRadius: "0px",
    borderBottomRightRadius: "0px",
    "&$checked": {
      color: "#FFFFFF",
    },

    width: "85%",
    maxWidth: "50vmax",
    maxHeight: "28vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },

  rootList: {
    background: "#28bf4b",
    color: "#FFFFFF",
    borderRadius: "15px",
    borderTopLeftRadius: "0px",
    borderTopRightRadius: "0px",
    "&$checked": {
      color: "#FFFFFF",
    },

    width: "85%",
    maxWidth: "50vmax",
    maxHeight: "20vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },

  checked: {},

  invisible: {
    background: "rgba(0,0,0,0.0)",
    color: "rgba(0,0,0,0.0)",
    "&hover": {},
    "&$invisibleChecked": {
      background: "rgba(0,0,0,0.0)",
      color: "rgba(0,0,0,0.0)",
    },
  },

  invisibleChecked: {},
}));

{
  /* Function to remove ingredient from EF, called when remove button pressed */
}
async function removeIngredient(ingredientToRemove, setExcludeIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/exclude/remove?ingredient=" +
      ingredientToRemove.name,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var excludeFridge = [];
  for (var i = 0; i < r.excludedIngredients.length; i++) {
    await excludeFridge.push(r.excludedIngredients[i]);
  }
  setExcludeIngredient(excludeFridge);
}

export default function ExclusionFridge(props) {
  const classes = useStyles();
  const { excludeIngredient, setExcludeIngredient } = props;

  {
    /* When remove button clicked */
  }
  async function removeHandler(ingredient) {
    removeIngredient(ingredient, setExcludeIngredient);
  }

  if (excludeIngredient == null) {
    return <div></div>;
  }

  return (
    <span>
      <List className={classes.rootHeader} style={{ marginLeft: "25%" }}>
        <ListSubheader
          style={{
            color: "#FFFFFF",
            fontFamily: "CarmenSansHeavy",
            fontSize: "4vh",
          }}
        >
          {`Exclude ingredients`}{" "}
        </ListSubheader>
      </List>
      <List className={classes.rootList} style={{ marginLeft: "25%" }}>
        {excludeIngredient.map((ingredient) => {
          const labelId = `checkbox-list-label-${ingredient.name}`;
          return (
            <ListItem key={ingredient.name} role={undefined} dense button>
              <ListItemIcon>
                <Checkbox
                  edge="start"
                  classes={{
                    root: classes.invisible,
                    checked: classes.invisibleChecked,
                  }}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </ListItemIcon>
              <span
                style={{ color: "#FFFFFF", fontFamily: "CarmenSansRegular" }}
              >
                {ingredient.name}
              </span>
              <ListItemSecondaryAction>
                <Tooltip
                  title="Remove from Exclusion List"
                  placement="top"
                  arrow
                >
                  <IconButton
                    onClick={() => removeHandler(ingredient)}
                    edge="end"
                    aria-label="remove"
                    style={{ color: "#FFFFFF" }}
                  >
                    <img src={trashCan} style={{ width: "4vh" }} />
                    {/*Image source: https://www.flaticon.com/free-icon/trash-can_3159662?term=remove&page=1&position=7#*/}
                  </IconButton>
                </Tooltip>
              </ListItemSecondaryAction>
            </ListItem>
          );
        })}
      </List>
    </span>
  );
}
