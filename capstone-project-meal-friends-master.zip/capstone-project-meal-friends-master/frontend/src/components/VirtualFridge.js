import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListSubheader from "@material-ui/core/ListSubheader";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import Checkbox from "@material-ui/core/Checkbox";
import IconButton from "@material-ui/core/IconButton";
import HighlightOffTwoToneIcon from "@material-ui/icons/HighlightOffTwoTone";
import trashCan from "../images/trashCan.svg";
import Tooltip from "@material-ui/core/Tooltip";

{
  /* Default theme, will change into "fridge" background */
}
const useStyles = makeStyles((theme) => ({
  rootHeader: {
    background: "#28bf4b",
    color: "#FFFFFF",
    borderRadius: "15px",
    borderBottomLeftRadius: "0px",
    borderBottomRightRadius: "0px",
    "&$checked": {
      color: "#FFFFFF",
    },

    width: "85%",
    maxWidth: "50vmax",
    maxHeight: "28vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },

  rootList: {
    background: "#28bf4b",
    color: "#FFFFFF",
    borderRadius: "15px",
    borderTopLeftRadius: "0px",
    borderTopRightRadius: "0px",
    "&$checked": {
      color: "#FFFFFF",
    },

    width: "85%",
    maxWidth: "50vmax",
    maxHeight: "20vh",
    overflow: "auto",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "CarmenSansSemiBold",
  },

  checked: {},

  invisible: {
    background: "rgba(0,0,0,0.0)",
    color: "rgba(0,0,0,0.0)",
    "&hover": {},
    "&$invisibleChecked": {
      background: "rgba(0,0,0,0.0)",
      color: "rgba(0,0,0,0.0)",
    },
  },

  invisibleChecked: {},
}));

{
  /* Function to remove ingredient from VF, called when remove button pressed */
}
async function removeIngredient(ingredientToRemove, setAddIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/remove?ingredient=" +
      ingredientToRemove.name,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var fridge = [];
  for (var i = 0; i < r.ingredients.length; i++) {
    await fridge.push(r.ingredients[i]);
  }
  setAddIngredient(fridge);
}

{
  /* Function to select (deselected) ingredient in VF, called when checkbox ticked */
}
async function selectIngredient(ingredientToSelect, setAddIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/select?ingredient=" +
      ingredientToSelect.name,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var fridge = [];
  for (var i = 0; i < r.ingredients.length; i++) {
    await fridge.push(r.ingredients[i]);
  }
  setAddIngredient(fridge);
}

{
  /* Function to deselect (selected) ingredient in VF, called when checkbox unticked */
}
async function deselectIngredient(ingredientToDeselect, setAddIngredient) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/deselect?ingredient=" +
      ingredientToDeselect.name,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var fridge = [];
  for (var i = 0; i < r.ingredients.length; i++) {
    await fridge.push(r.ingredients[i]);
  }
  setAddIngredient(fridge);
}

export default function VirtualFridge(props) {
  const classes = useStyles();
  const { addIngredient, setAddIngredient } = props;
  const [checked, setChecked] = React.useState([0]);

  {
    /* When checkbox ticked/unticked */
  }
  async function selectHandler(ingredient) {
    if (ingredient.selected) {
      deselectIngredient(ingredient, setAddIngredient);
    } else {
      selectIngredient(ingredient, setAddIngredient);
    }
  }

  {
    /* When remove button clicked */
  }
  async function removeHandler(ingredient) {
    removeIngredient(ingredient, setAddIngredient);
  }

  if (addIngredient == null) {
    return <div></div>;
  }

  return (
    <span>
      <List className={classes.rootHeader} style={{ marginLeft: "25%" }}>
        <ListSubheader
          style={{
            color: "#FFFFFF",
            fontFamily: "CarmenSansHeavy",
            fontSize: "4vh",
          }}
        >
          {`Include ingredients`}{" "}
        </ListSubheader>
      </List>
      <List className={classes.rootList} style={{ marginLeft: "25%" }}>
        {addIngredient.map((ingredient) => {
          const labelId = `checkbox-list-label-${ingredient.name}`;
          return (
            <ListItem
              key={ingredient.name}
              role={undefined}
              dense
              button
              onClick={() => selectHandler(ingredient)}
            >
              <ListItemIcon>
                <Checkbox
                  edge="start"
                  checked={ingredient.selected}
                  classes={{
                    root: classes.rootList,
                    checked: classes.checked,
                  }}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </ListItemIcon>
              <span
                style={{ color: "#FFFFFF", fontFamily: "CarmenSansRegular" }}
              >
                {ingredient.name}
              </span>
              <ListItemSecondaryAction>
                <Tooltip
                  title="Remove from Virtual Fridge"
                  placement="top"
                  arrow
                >
                  <IconButton
                    onClick={() => removeHandler(ingredient)}
                    edge="end"
                    aria-label="remove"
                  >
                    <img src={trashCan} style={{ width: "4vh" }} />
                    {/*Image source: https://www.flaticon.com/free-icon/trash-can_3159662?term=remove&page=1&position=7#*/}
                  </IconButton>
                </Tooltip>
              </ListItemSecondaryAction>
            </ListItem>
          );
        })}
      </List>
    </span>
  );
}

export { removeIngredient };
