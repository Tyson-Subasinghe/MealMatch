import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import plus from "../images/plus.svg";
import minus from "../images/minus.svg";
import shoppingCartImage from "../images/shoppingCartImage.svg";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "space-around",
    overflow: "hidden",
    backgroundColor: "rgb(255,255,255,1)",
    fontFamily: "CarmenSansSemiBold",

    borderRadius: 35,
    border: 0,
  },
  gridList: {
    flexWrap: "wrap",
    width: "80vw",
    height: "40vh",

    // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
    transform: "translateZ(0)",
  },

  title: {
    color: theme.palette.primary.light,
  },
  titleBar: {
    background:
      "linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)",
  },
  buttonText: {},
}));

async function addIngredient(
  ingredientToAdd,
  setInput,
  setTileData,
  setAddIngredient
) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/add?ingredient=" + ingredientToAdd,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var fridge = [];
  for (var i = 0; i < r.ingredients.length; i++) {
    await fridge.push(r.ingredients[i]);
  }
  setAddIngredient(fridge);
  setInput("");
  setTileData(null);
}

async function excludeIngredient(
  ingredientToExclude,
  setInput,
  setTileData,
  setExcludeIngredient
) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/exclude/add?ingredient=" +
      ingredientToExclude,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var excludeFridge = [];
  for (var i = 0; i < r.excludedIngredients.length; i++) {
    await excludeFridge.push(r.excludedIngredients[i]);
  }
  setExcludeIngredient(excludeFridge);
  setInput("");
  setTileData(null);
}

async function shopIngredient(
  ingredientToShop,
  setInput,
  setTileData,
  setShopIngredient
) {
  let res = await fetch(
    "http://127.0.0.1:5000/api/ingredient/shopping/add?ingredient=" +
      ingredientToShop,
    {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
  let r = await res.json();
  var shoppingList = [];
  for (var i = 0; i < r.shoppingList.length; i++) {
    await shoppingList.push(r.shoppingList[i]);
  }
  setShopIngredient(shoppingList);
  setInput("");
  setTileData(null);
}

export default function IngredientResultGridList(props) {
  const classes = useStyles();
  const {
    tileData,
    setInput,
    setTileData,
    setAddIngredient,
    setExcludeIngredient,
    setShopIngredient,
    setScrolling,
  } = props;

  async function addHandler(ingredientToAdd) {
    addIngredient(ingredientToAdd, setInput, setTileData, setAddIngredient);
  }

  async function excludeHandler(ingredientToExclude) {
    excludeIngredient(
      ingredientToExclude,
      setInput,
      setTileData,
      setExcludeIngredient
    );
  }

  async function cartHandler(ingredientToShop) {
    shopIngredient(ingredientToShop, setInput, setTileData, setShopIngredient);
  }

  var gridStyle = {
    position: "relative",
    float: "left",
    minHeight: "0px",
    overflow: "hidden",
    height: "100%",
  };

  var buttonStyle = {
    fontSize: "3vmin",
    background: "#FFFFFF",
    color: "#28bf4b",
    borderRadius: 10,
    border: 0,
    height: 0,
    padding: "10px 10px 10px 10px",
    textTransform: "None",
    fontFamily: "CarmenSansSemiBold",
  };

  if (tileData == null) {
    return <div></div>;
  }
  return (
    <div
      className={classes.root}
      style={{ width: "80%", marginLeft: "10%" }}
      onMouseEnter={() => {
        setScrolling(false);
      }}
      onMouseLeave={() => {
        setScrolling(true);
      }}
    >
      <GridList className={classes.gridList} cols={3}>
        {tileData.map((tile) => (
          <GridListTile key={tile.name} style={gridStyle}>
            <div
              style={{
                textAlign: "center",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "5%",
              }}
            >
              {tile.name}
              {"\n"}
              <div style={{ marginTop: "2vh" }}>
                <img
                  src={tile.img}
                  label={tile.name}
                  style={{ height: "18vh" }}
                />
              </div>
              <div style={{ marginTop: "1vh" }}>
                {/* Three IconButtons per ingredient result - to add, exclude and cart. Includes ToolTip for each button */}
                {/* TODO: Agree on consistent wording for the three ingredient actions*/}
                <Tooltip
                  title="Add this ingredient to your Virtual Fridge to find recipes with it"
                  placement="top"
                  arrow
                >
                  <IconButton onClick={() => addHandler(tile.name)}>
                    <img src={plus} style={{ width: "4vh" }} />
                  </IconButton>
                </Tooltip>
                <Tooltip
                  title="Add this ingredient to your Exclusion List to exclude recipes with it"
                  placement="top"
                  arrow
                >
                  <IconButton onClick={() => excludeHandler(tile.name)}>
                    <img src={minus} style={{ width: "4vh" }} />
                  </IconButton>
                </Tooltip>
                {/*TODO: Currently ShoppingCart not functioning - need to link with B/E when completed */}
                <Tooltip
                  title="Add this ingredient to your Shopping List to find recipes with it"
                  placement="top"
                  arrow
                >
                  <IconButton onClick={() => cartHandler(tile.name)}>
                    <img src={shoppingCartImage} style={{ width: "4vh" }} />
                  </IconButton>
                </Tooltip>
              </div>
            </div>
          </GridListTile>
        ))}
      </GridList>
    </div>
  );
}

export { shopIngredient };
