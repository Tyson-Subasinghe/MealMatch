import React, { useRef, useState, useEffect } from "react";
import { Spring, config } from "react-spring/renderprops";
import { Parallax, ParallaxLayer } from "react-spring/renderprops-addons";

import "./App.css";

// Components for Page 1 - Log in
import TabBar from "./components/TabBar.js";
import TypicalText from "./components/TypicalText.js";
import Login from "./components/Login.js";
import RedirectButton from "./components/RedirectButton";
import GuestButton from "./components/GuestButton.js";

// Components for Page 2 - Ingredients search
import InputForm from "./components/InputForm.js";
import SearchIngredientButton from "./components/SearchIngredientButton.js";
import SuggestIngredientButton from "./components/SuggestIngredientButton.js";
import IngredientResultGridList from "./components/IngredientResultGridList.js";
import SuggestIngredientPopUp from "./components/SuggestIngredientPopUp.js";
import VirtualFridgePopUp from "./components/VirtualFridgePopUp.js";
import ExclusionFridgePopUp from "./components/ExclusionFridgePopUp.js";
import ShoppingListPopUp from "./components/ShoppingListPopUp.js";
import beans from "./images/beans.svg";
import chili from "./images/chili.svg";
import crab from "./images/crab.svg";
import fruit from "./images/fruit.svg";
import straw from "./images/straw.svg";

// Components for Page 3 - Virtual Fridge
import VirtualFridge from "./components/VirtualFridge.js";
import ExclusionFridge from "./components/ExclusionFridge.js";
import ShoppingList from "./components/ShoppingList.js";
import NearbyStores from "./components/NearbyStores.js";
import EmailShoppingButton from "./components/EmailShoppingButton.js";
import EmailSentPopUp from "./components/EmailSentPopUp.js";
import NearbyStoresPopUp from "./components/NearbyStoresPopUp.js";
import NearbyStoresButton from "./components/NearbyStoresButton.js";

// Components for Page 4 - Recipe results
import IngredientRemovalPopUp from "./components/IngredientRemovalPopUp.js";
import SortRecipeMenu from "./components/SortRecipeMenu.js";
import SortRecipeSwitch from "./components/SortRecipeSwitch.js";
import DietaryRequirementsButton from "./components/DietaryRequirementsButton.js";
import ResultGridList from "./components/ResultGridList.js";
import RecipeResultGridList from "./components/RecipeResultGridList";

{
  /* Current design language: */
}
{
  /* Main focus of page speed at 0.5, secondary at 0.3, buttons at 0.1 */
}

export default function App() {
  {
    /* DATA SECTION */
  }

  // Data for text
  const [typicalRenderState, setTypicalRenderState] = useState("original");
  {
    /* State of typical text rendering*/
  }
  function triggerSetRenderState() {
    setTypicalRenderState("thanks");
    {
      /* Triggers the second state */
    }
  }

  // Data for Login
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isGuest, setIsGuest] = useState(false);
  const [user, setUser] = useState(false);
  const [username, setUsername] = useState(null);
  const [usernameInput, setUsernameInput] = useState("");
  const [checkedIfLoggedIn, setCheckedIfLoggedIn] = useState(false);

  // Data for ingredients
  const [input, setInput] = useState("");
  const [submitClickState, setSubmitClickState] = useState(0);
  const [searchIngredient, setSearchIngredient] = useState(null);
  const [addIngredient, setAddIngredient] = useState(null);
  const [excludeIngredient, setExcludeIngredient] = useState(null);
  const [shopIngredient, setShopIngredient] = useState(null);
  const [suggestIngredient, setSuggestIngredient] = useState(null);
  const [suggestOpenState, setSuggestOpenState] = useState(false);
  const [nearbyStoresOpenState, setNearbyStoresOpenState] = useState(false);

  // Data for email
  const [sendEmail, setSendEmail] = useState(null);

  // Data for recipes
  const [sortType, setSortType] = useState("missedIngredientCount");
  const [sortAscending, setSortAscending] = useState(true);
  const [dietFilters, setDietFilters] = useState(null);
  const [cuisineFilters, setCuisineFilters] = useState(null);
  const [mealTypeFilters, setMealTypeFilters] = useState(null);
  const [recipes, setRecipes] = useState(null);

  {
    /* To load past data for the three fridge */
  }
  async function loadPastData() {
    let res = await fetch("http://127.0.0.1:5000/api/user/details", {
      mode: "cors",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });
    let userData = await res.json();

    var fridge = [];
    for (var i = 0; i < userData.ingredients.length; i++) {
      await fridge.push(userData.ingredients[i]);
    }
    await setAddIngredient(fridge);

    var excludeFridge = [];
    for (var i = 0; i < userData.excludedIngredients.length; i++) {
      await excludeFridge.push(userData.excludedIngredients[i]);
    }
    await setExcludeIngredient(excludeFridge);

    var shoppingList = [];
    for (var i = 0; i < userData.shoppingList.length; i++) {
      await shoppingList.push(userData.shoppingList[i]);
    }
    await setShopIngredient(shoppingList);

    if (userData.profile.googleId != null) {
      await setIsLoggedIn(true);
    }
  }

  if (!checkedIfLoggedIn) {
    loadPastData();
    {
      /* PASS DATA DOWN TO FUNCTIONAL SUBCOMPONENTS VIA dataNameInSubcomponent.js = {dataNameInApp.js}*/
    }

    setCheckedIfLoggedIn(true);
  }

  {
    /* END OF DATA SECTION */
  }

  {
    /* Logo as an object to make things neater*/
  }
  var Logo = <span className="Logo"> MealMatch </span>;
  var SubmitPrompt = <span className="SubmitPrompt"> You can make: </span>;
  var QuestionPrompt = (
    <span className="QuestionPrompt"> What do you have? </span>
  );
  var Results = <span className="SubmitPrompt"> {recipes} </span>;

  {
    /* PARALLAX SCROLLING THINGS */
  }

  {
    /* Initialise parallax page ref as a global variable */
  }
  var parallaxPageRef;
  const [scrolling, setScrolling] = useState(false);
  {
    /* Create a function which can be called inside subcomponents */
  }
  function scrollTo(location) {
    parallaxPageRef.scrollTo(location);
  }

  {
    /* CONTENT */
  }
  {
    /* Create webPage document using Parallax and ParallaxLayer*/
  }

  const webPage = (
    <React.Fragment>
      <TabBar
        scrollTo={scrollTo}
        setScrolling={setScrolling}
        isLoggedIn={isLoggedIn}
        isGuest={isGuest}
        setRecipes={setRecipes}
      />

      <Parallax
        ref={(ref) => (parallaxPageRef = ref)}
        pages={5}
        scrolling={false}
        style={{ height: "93%", display: "flex" }}
      >
        {/* PAGE 1 - Log in*/}
        {/* Background */}
        <ParallaxLayer
          offset={0}
          speed={scrolling ? 1 : 0}
          factor={2}
          style={{ backgroundColor: "#FFFFFF" }}
        />
        <ParallaxLayer
          offset={0}
          speed={0}
          factor={1}
          style={{
            backgroundImage:
              "url(" +
              "https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" +
              ")",
            backgroundPosition: "center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
          }}
        />

        {/* MealMatch Logo */}
        <ParallaxLayer
          offset={0.2}
          speed={scrolling ? 0.5 : 0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          {Logo}
        </ParallaxLayer>

        {/* Welcome message */}
        <ParallaxLayer
          offset={0.53}
          speed={scrolling ? 0.3 : 0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <TypicalText
            renderState={typicalRenderState}
            setRenderState={setTypicalRenderState}
            username={username}
            isLoggedIn={isLoggedIn}
            isGuest={isGuest}
          />
        </ParallaxLayer>

        {/* Log in and guest buttons */}
        <ParallaxLayer
          offset={0.8}
          speed={scrolling ? 0.1 : 0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <Login
            setIsLoggedIn={setIsLoggedIn}
            isLoggedIn={isLoggedIn}
            user={user}
            setUser={setUser}
            username={username}
            setUsername={setUsername}
            setIsGuest={setIsGuest}
            setScrolling={setScrolling}
            loadPastData={loadPastData}
          />

          {isLoggedIn || isGuest ? (
            <RedirectButton
              scrollTo={scrollTo}
              scrollToWhere={1}
              text={"Ingredient Search"}
              styles={{ marginLeft: "6%", padding: "0% 10%" }}
            />
          ) : (
            <GuestButton
              isGuest={isGuest}
              setIsGuest={setIsGuest}
              setScrolling={setScrolling}
              styles={{ marginLeft: "6%", padding: "0% 10%" }}
            />
          )}
        </ParallaxLayer>

        {/* END OF PAGE 1 */}

        {/* PAGE 2 - Ingredients search */}
        {/* Background */}
        <ParallaxLayer
          offset={1}
          speed={0}
          factor={1}
          style={{
            backgroundImage:
              "url(" +
              "https://images.pexels.com/photos/461428/pexels-photo-461428.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" +
              ")",
            backgroundPosition: "center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
          }}
        />

        {/* Food images */}
        <ParallaxLayer offset={1.3} speed={scrolling ? 0.8 : 0} factor={0}>
          <img
            src={fruit}
            className="App-logo"
            alt="logo"
            style={{ width: "10%", marginLeft: "80%" }}
          />
        </ParallaxLayer>
        <ParallaxLayer offset={1.5} speed={scrolling ? -0.3 : 0} factor={0}>
          <img
            src={beans}
            className="App-logo"
            alt="logo"
            style={{ width: "10%", marginLeft: "80%" }}
          />
        </ParallaxLayer>
        <ParallaxLayer offset={1.2} speed={scrolling ? -0.2 : 0} factor={0}>
          <img
            src={chili}
            className="App-logo"
            alt="logo"
            style={{ width: "7%", marginLeft: "75%" }}
          />
        </ParallaxLayer>
        <ParallaxLayer offset={1.75} speed={scrolling ? 0.8 : 0} factor={0}>
          <img
            src={crab}
            className="App-logo"
            alt="logo"
            style={{ width: "10%", marginLeft: "75%" }}
          />
        </ParallaxLayer>
        <ParallaxLayer offset={1.4} speed={scrolling ? 0.9 : 0} factor={0}>
          <img
            src={straw}
            className="App-logo"
            alt="logo"
            style={{ width: "13%", marginLeft: "65%" }}
          />
        </ParallaxLayer>

        {/* Ingredient search question*/}
        <ParallaxLayer
          offset={1.05}
          speed={scrolling ? 0.5 : 0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          {QuestionPrompt}
        </ParallaxLayer>

        {/* Search bar */}
        <ParallaxLayer
          offset={1.2}
          speed={scrolling ? 0.3 : 0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <InputForm
            clickState={submitClickState}
            setClickState={setSubmitClickState}
            input={input}
            setSearchIngredient={setSearchIngredient}
            setInput={setInput}
            text={"Enter ingredient"}
          />
        </ParallaxLayer>

        <ParallaxLayer offset={1.5} speed={0} factor={0}>
          {/* Ingredients search results - as grid */}
          <div style={{ justifyContent: "center", alignItems: "center" }}>
            <IngredientResultGridList
              tileData={searchIngredient}
              setTileData={setSearchIngredient}
              setAddIngredient={setAddIngredient}
              setExcludeIngredient={setExcludeIngredient}
              setShopIngredient={setShopIngredient}
              setInput={setInput}
              setScrolling={setScrolling}
            />
          </div>

          {/* Suggested ingredient result - as pop up */}
          <div style={{ justifyContent: "center", alignItems: "center" }}>
            <SuggestIngredientPopUp
              suggestOpenState={suggestOpenState}
              setSuggestOpenState={setSuggestOpenState}
              suggestIngredient={suggestIngredient}
              setAddIngredient={setAddIngredient}
              setExcludeIngredient={setExcludeIngredient}
              setShopIngredient={setShopIngredient}
            />
          </div>
        </ParallaxLayer>

        {/* Search/suggest ingredient button */}
        <ParallaxLayer
          offset={1.35}
          speed={scrolling ? 0.1 : 0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <SearchIngredientButton
            input={input}
            setInput={setInput}
            setSearchIngredient={setSearchIngredient}
          />
          <div style={{ marginLeft: "6%" }}>
            <SuggestIngredientButton
              setSuggestOpenState={setSuggestOpenState}
              setSuggestIngredient={setSuggestIngredient}
            />
          </div>
        </ParallaxLayer>

        {/* Alerts for adding ingredients to Virtual Fridge */}
        <ParallaxLayer
          offset={1.9}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <VirtualFridgePopUp
            addIngredient={addIngredient}
            setAddIngredient={setAddIngredient}
          />
          <ExclusionFridgePopUp
            excludeIngredient={excludeIngredient}
            setExcludeIngredient={setExcludeIngredient}
          />
          <ShoppingListPopUp
            shopIngredient={shopIngredient}
            setShopIngredient={setShopIngredient}
          />
        </ParallaxLayer>

        {/* END OF PAGE 2 */}

        {/* PAGE 3 - Virtual Fridge*/}
        {/* Background image */}
        <ParallaxLayer
          offset={2}
          speed={0}
          factor={1}
          style={{
            backgroundImage:
              "url(" +
              "https://images.pexels.com/photos/2343467/pexels-photo-2343467.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" +
              ")",
            backgroundPosition: "center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
          }}
        />

        {/* Virtual fridge, exclusion list and shopping list */}
        <ParallaxLayer offset={2.05} speed={0} factor={0}>
          <div style={{ alignItems: "center", justifyContent: "center" }}>
            <VirtualFridge
              addIngredient={addIngredient}
              setAddIngredient={setAddIngredient}
            />
            <div style={{ marginTop: "0.5%" }}>
              <ExclusionFridge
                excludeIngredient={excludeIngredient}
                setExcludeIngredient={setExcludeIngredient}
              />
            </div>
            <div style={{ marginTop: "0.5%" }}>
              <ShoppingList
                shopIngredient={shopIngredient}
                setShopIngredient={setShopIngredient}
                setAddIngredient={setAddIngredient}
              />
            </div>
          </div>
        </ParallaxLayer>

        {/* Google Map for nearby stores */}
        <ParallaxLayer
          offset={2.05}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "right" }}
        >
          <div style={{ justifyContent: "center", alignItems: "center" }}>
            <NearbyStoresPopUp
              nearbyStoresOpenState={nearbyStoresOpenState}
              setNearbyStoresOpenState={setNearbyStoresOpenState}
            />
          </div>
        </ParallaxLayer>

        {/* Email shopping list sent popup */}
        <ParallaxLayer
          offset={2.8}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <EmailSentPopUp sendEmail={sendEmail} setSendEmail={setSendEmail} />
        </ParallaxLayer>

        {/* Email shopping list button */}
        <ParallaxLayer
          offset={2.87}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <div style={{ marginLeft: "75%" }}>
            <EmailShoppingButton
              isLoggedIn={isLoggedIn}
              setSendEmail={setSendEmail}
            />
          </div>
        </ParallaxLayer>

        {/* Find nearby stores button */}
        <ParallaxLayer
          offset={2.77}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <div style={{ marginLeft: "75%" }}>
            <NearbyStoresButton
              setNearbyStoresOpenState={setNearbyStoresOpenState}
            />
          </div>
        </ParallaxLayer>

        {/* END OF PAGE 3 */}

        {/* PAGE 4 - Recipe results */}
        <ParallaxLayer
          offset={3}
          speed={0}
          factor={1}
          style={{ backgroundColor: "#28bf4b" }}
        />

        {/* "You can make" header */}
        <ParallaxLayer
          offset={3.05}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          {SubmitPrompt}
        </ParallaxLayer>

        {/* Sorting and filtering side panel */}
        <ParallaxLayer
          offset={3.05}
          speed={0}
          factor={0}
          style={{ alignItems: "left", justifyContent: "center" }}
        >
          <SortRecipeMenu
            recipes={recipes}
            setRecipes={setRecipes}
            sortType={sortType}
            setSortType={setSortType}
            sortAscending={sortAscending}
          />
          <SortRecipeSwitch
            recipes={recipes}
            setRecipes={setRecipes}
            sortType={sortType}
            sortAscending={sortAscending}
            setSortAscending={setSortAscending}
          />
          <DietaryRequirementsButton
            dietFilters={dietFilters}
            setDietFilters={setDietFilters}
            cuisineFilters={cuisineFilters}
            setCuisineFilters={setCuisineFilters}
            mealTypeFilters={mealTypeFilters}
            setMealTypeFilters={setMealTypeFilters}
            recipes={recipes}
            setRecipes={setRecipes}
          />
        </ParallaxLayer>

        {/* Alerts for removing ingredient from VF / adding to SL */}
        <ParallaxLayer
          offset={3.1}
          speed={0}
          factor={0}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <IngredientRemovalPopUp
            addIngredient={addIngredient}
            setAddIngredient={setAddIngredient}
          />
          <ShoppingListPopUp
            shopIngredient={shopIngredient}
            setShopIngredient={setShopIngredient}
          />
        </ParallaxLayer>

        {/* Recipe search results */}
        <ParallaxLayer
          offset={3.1}
          speed={0}
          factor={0}
          style={{ justifyContent: "center" }}
        >
          <RecipeResultGridList
            tileData={recipes}
            setScrolling={setScrolling}
            setAddIngredient={setAddIngredient}
            setShopIngredient={setShopIngredient}
            isLoggedIn={isLoggedIn}
          />
        </ParallaxLayer>
      </Parallax>
    </React.Fragment>
  );

  {
    /* Return constructed webPage*/
  }
  return webPage;
}
