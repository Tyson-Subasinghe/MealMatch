"""
Run all tests from the api/ directory with by running either
    `py.test`
    or
    `python -m pytest test/`
"""

import os
import sys

import pytest

# add the api/ folder to path so our classes can be imported below

sys.path.append(os.getcwd())

import api_accessor
import constants
from meal_system import MealSystem
from exceptions import NoIngredientError
from test.test_setup import *
from test.recipe_info_test_cases import *


@pytest.fixture(scope="function", autouse=True)
def system_fixture() -> MealSystem:
    reset_caches()
    system_fixture = MealSystem()
    return system_fixture


class TestSearchIngredient:
    """
    This class should test functions associated with ingredients (add, search etc).
    It makes calls directly to meal_system and mocks the Spoonacular API results.
    We should discuss our approach to testing and maybe restructure these.
    """

    def test_search_ingredient_none_added(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        results = system_fixture.user_search_ingredient(UID1, "apple")
        assert results == APPLE_RESULTS

    def test_search_ingredient_excludes_added_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")

        results = system_fixture.user_search_ingredient(UID1, "apple")

        assert results[0].name == "apple cider vinegar"  # the remaining ingredient

    def test_search_ingredient_in_excluded_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.user_exclude_ingredient(UID1, "apple")
        results = system_fixture.user_search_ingredient(UID1, "apple")
        assert len(results) == 2
        assert "apple" not in results.names
        assert "applesauce" in results.names
        assert "apple cider vinegar" in results.names

    def test_search_ingredient_in_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.add_to_shopping_list(UID1, "apple")
        results = system_fixture.user_search_ingredient(UID1, "apple")
        assert len(results) == 2
        assert "apple" not in results.names
        assert "applesauce" in results.names
        assert "apple cider vinegar" in results.names

    def test_search_ingredient_no_results(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = IngredientCollection()

        result = system_fixture.user_search_ingredient(UID1, "random-weird-string")
        assert len(result) == 0
        assert not system_fixture.get_user(UID1).all_ingredients


class TestAddIngredient:

    def test_add_first_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0
        system_fixture.user_add_ingredient(UID1, "apple")

        assert system_fixture.get_user(UID1).virtual_fridge[0].name == "apple"

    def test_add_multiple_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0
        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")

        ingredient_details = system_fixture.get_user(UID1).virtual_fridge

        assert len(ingredient_details) == 2
        assert ingredient_details[0].name == "apple"
        assert ingredient_details[1].name == "applesauce"


class TestRemoveIngredient:

    def test_remove_first_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_add_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 1
        system_fixture.user_remove_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0

    def test_remove_several_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")
        system_fixture.user_add_ingredient(UID1, "apple cider vinegar")

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 3
        system_fixture.user_remove_ingredient(UID1, "applesauce")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 2
        assert "applesauce" not in system_fixture.get_user(UID1).virtual_fridge.names
        assert "apple" in system_fixture.get_user(UID1).virtual_fridge.names
        assert "apple cider vinegar" in system_fixture.get_user(UID1).virtual_fridge.names

        system_fixture.user_remove_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 1
        assert "apple cider vinegar" in system_fixture.get_user(UID1).virtual_fridge.names

        system_fixture.user_remove_ingredient(UID1, "apple cider vinegar")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0

    def test_remove_non_existent_ingredient_fails(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_add_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 1

        with pytest.raises(NoIngredientError):
            system_fixture.user_remove_ingredient(UID1, "random-string-not-an-ingredient")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 1


class TestSelectIngredient:

    def test_ingredient_selected_by_default(self, system_fixture, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert not system_fixture.get_user(UID1).virtual_fridge
        system_fixture.user_add_ingredient(UID1, "apple")

        assert system_fixture.get_user(UID1).virtual_fridge[0].selected is True

    def test_ingredient_deselection(self, system_fixture, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0
        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")
        system_fixture.deselect_user_ingredient(UID1, "apple")

        assert system_fixture.get_user(UID1).virtual_fridge[0].selected is False
        assert system_fixture.get_user(UID1).virtual_fridge[1].selected is True

        system_fixture.deselect_user_ingredient(UID1, "apple")  # Nothing should change

        assert system_fixture.get_user(UID1).virtual_fridge[0].selected is False
        assert system_fixture.get_user(UID1).virtual_fridge[1].selected is True

    def test_ingredient_selection(self, system_fixture, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0
        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")

        system_fixture.deselect_user_ingredient(UID1, "apple")

        assert system_fixture.get_user(UID1).virtual_fridge[0].selected is False
        assert system_fixture.get_user(UID1).virtual_fridge[1].selected is True

        system_fixture.select_user_ingredient(UID1, "apple")

        assert system_fixture.get_user(UID1).virtual_fridge[0].selected is True
        assert system_fixture.get_user(UID1).virtual_fridge[1].selected is True

    def test_exception_when_deselected_ingredient_not_present(self, system_fixture, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0
        system_fixture.user_add_ingredient(UID1, "apple")

        with pytest.raises(NoIngredientError):
            system_fixture.deselect_user_ingredient(UID1, "any-other-ingredient")

    def test_exception_when_selected_ingredient_not_present(self, system_fixture, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0
        system_fixture.user_add_ingredient(UID1, "apple")

        with pytest.raises(NoIngredientError):
            system_fixture.select_user_ingredient(UID1, "any-other-ingredient")


class TestAddExcludeIngredient:
    def test_add_one_excluded_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 0
        system_fixture.user_exclude_ingredient(UID1, "apple")

        assert system_fixture.get_user(UID1).excluded_ingredients[0].name == "apple"

    def test_add_multiple_excluded_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = APPLE_RESULTS

        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 0
        system_fixture.user_exclude_ingredient(UID1, "apple")
        system_fixture.user_exclude_ingredient(UID1, "applesauce")

        excluded_ingredient_details = system_fixture.get_user(UID1).excluded_ingredients

        assert len(excluded_ingredient_details) == 2
        assert excluded_ingredient_details[0].name == "apple"
        assert excluded_ingredient_details[1].name == "applesauce"


class TestRemoveExcludedIngredient:

    def test_remove_one_excluded_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(external_accessor, "search_ingredient")
        external_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_exclude_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 1
        system_fixture.user_remove_excluded_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 0

    def test_remove_several_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(external_accessor, "search_ingredient")
        external_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_exclude_ingredient(UID1, "apple")
        system_fixture.user_exclude_ingredient(UID1, "applesauce")
        system_fixture.user_exclude_ingredient(UID1, "apple cider vinegar")

        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 3
        system_fixture.user_remove_excluded_ingredient(UID1, "applesauce")
        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 2
        assert "applesauce" not in system_fixture.get_user(UID1).excluded_ingredients.names
        assert "apple" in system_fixture.get_user(UID1).excluded_ingredients.names
        assert "apple cider vinegar" in system_fixture.get_user(UID1).excluded_ingredients.names

        system_fixture.user_remove_excluded_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 1
        assert "apple cider vinegar" in system_fixture.get_user(UID1).excluded_ingredients.names

        system_fixture.user_remove_excluded_ingredient(UID1, "apple cider vinegar")
        assert len(system_fixture.get_user(UID1).virtual_fridge) == 0

    def test_remove_non_existent_ingredient_fails(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(external_accessor, "search_ingredient")
        external_accessor.search_ingredient.return_value = APPLE_RESULTS

        system_fixture.user_exclude_ingredient(UID1, "apple")
        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 1

        with pytest.raises(NoIngredientError):
            system_fixture.user_remove_excluded_ingredient(UID1, "random-string-not-an-ingredient")
        assert len(system_fixture.get_user(UID1).excluded_ingredients) == 1


class TestExcludeIngredientRecipeSearch:
    def test_search_with_one_excluded_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        system_fixture.user_exclude_ingredient(UID1, "milk")
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_NO_MILK
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 1
        recipe_ids = set(result["id"] for result in results)
        assert 1 in recipe_ids

    def test_search_with_multiple_excluded_ingredients(self, system_fixture: MealSystem, mocker):
        """
        Note that this test mocks external accessor instead of api_accessor.
        That's because the caching that occurs after search_recipes_by_ingredients()
        seems to prevent the mocked Spoonacular API call from running at all.
        """
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        system_fixture.user_exclude_ingredient(UID1, "flour")
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_NO_FLOUR
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 3
        recipe_ids = set(result["id"] for result in results)
        assert 1 in recipe_ids
        assert 2 in recipe_ids
        assert 4 in recipe_ids

        system_fixture.user_exclude_ingredient(UID1, "potato")
        mocker.patch.object(external_accessor, "get_recipe_info")
        external_accessor.get_recipe_info.return_value = RECIPE_INFO_NO_FLOUR_NO_POTATO
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients

        assert len(results) == 2
        recipe_ids = set(result["id"] for result in results)
        assert 1 in recipe_ids
        assert 2 in recipe_ids

        system_fixture.user_exclude_ingredient(UID1, "carrot")
        mocker.patch.object(external_accessor, "get_recipe_info")
        external_accessor.get_recipe_info.return_value = RECIPE_INFO_EMPTY
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 0


class TestRemoveIngredients:
    def test_remove_single_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")
        system_fixture.user_add_ingredient(UID1, "apple cider vinegar")

        system_fixture.user_remove_ingredients(UID1, ["applesauce"])

        vf = system_fixture.user_to_dict(UID1)["ingredients"]
        assert len(vf) == 2
        assert vf[0]["name"] == "apple"
        assert vf[1]["name"] == "apple cider vinegar"

    def test_remove_multiple_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")
        system_fixture.user_add_ingredient(UID1, "apple cider vinegar")

        system_fixture.user_remove_ingredients(UID1, ["applesauce", "apple"])

        vf = system_fixture.user_to_dict(UID1)["ingredients"]
        assert len(vf) == 1
        assert vf[0]["name"] == "apple cider vinegar"


class TestIngredientSuggestions:
    def test_initial_suggestions(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        result = system_fixture.suggest_ingredient(UID1)
        assert result == constants.STARTER_INGREDIENT_SUGGESTIONS[0]
        result = system_fixture.suggest_ingredient(UID1)
        assert result == constants.STARTER_INGREDIENT_SUGGESTIONS[1]
        result = system_fixture.suggest_ingredient(UID1)
        assert result == constants.STARTER_INGREDIENT_SUGGESTIONS[2]

    def test_user_ingredients_are_removed_from_suggestions(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        assert len(constants.STARTER_INGREDIENT_SUGGESTIONS) > 4  # Pre condition

        system_fixture.user_add_ingredient(UID1, constants.STARTER_INGREDIENT_SUGGESTIONS[0].name)
        system_fixture.user_exclude_ingredient(UID1, constants.STARTER_INGREDIENT_SUGGESTIONS[1].name)
        system_fixture.add_to_shopping_list(UID1, constants.STARTER_INGREDIENT_SUGGESTIONS[2].name)

        result = system_fixture.suggest_ingredient(UID1)
        assert result == constants.STARTER_INGREDIENT_SUGGESTIONS[3]
        result = system_fixture.suggest_ingredient(UID1)
        assert result == constants.STARTER_INGREDIENT_SUGGESTIONS[4]

    def test_exception_with_no_possible_suggestions(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = []
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = []

        assert len(constants.STARTER_INGREDIENT_SUGGESTIONS) < 20  # Pre condition

        with pytest.raises(NoIngredientError):
            for i in range(20):
                system_fixture.suggest_ingredient(UID1)

    def test_recipe_search_prepends_suggestions(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_search_recipes(UID1)

        result = system_fixture.suggest_ingredient(UID1)
        assert result.name in ['baking powder', 'milk', 'flour', 'some ingredient', 'potato']
        result2 = system_fixture.suggest_ingredient(UID1)
        assert result2.name in ['baking powder', 'milk', 'flour', 'some ingredient', 'potato']
        assert result.name != result2.name

    def test_additional_suggestions_found(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients", return_value=[])
        mocker.patch.object(api_accessor, "get_recipe_info", return_value=[])

        # Clear out all pending suggestions with no others added
        for i in range(20):
            try:
                system_fixture.suggest_ingredient(UID1)
            except NoIngredientError:
                pass

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients", return_value=SEARCH_BY_INGREDIENT_RESULTS)
        mocker.patch.object(api_accessor, "get_recipe_info", return_value=RECIPE_INFO_BULK)

        system_fixture.user_add_ingredient(UID1, "egg")

        result = system_fixture.suggest_ingredient(UID1)
        assert result.name in ['baking powder', 'milk', 'flour', 'some ingredient', 'potato']
        result2 = system_fixture.suggest_ingredient(UID1)
        assert result2.name in ['baking powder', 'milk', 'flour', 'some ingredient', 'potato']
        assert result.name != result2.name
