"""
Run all tests from the api/ directory with by running either
    `py.test`
    or
    `python -m pytest test/`
"""

import os
import sys

import pytest

# add the api/ folder to path so our classes can be imported below

sys.path.append(os.getcwd())

import api_accessor
from meal_system import MealSystem
from exceptions import FilterNotSupportedError
from test.recipe_info_test_cases import *
from test.test_setup import *


@pytest.fixture(scope="function", autouse=True)
def system_fixture() -> MealSystem:
    reset_caches()
    system_fixture = MealSystem()
    return system_fixture


class TestRecipeSearch:
    """
    This class should test functions associated with searching recipes.
    Test cases mocked in recipe_info_test_cases.
    Not sure how rigorous these tests really are, open for further discussion.
    """

    def test_search_recipe_exclude_deselected(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(external_accessor, "search_ingredient")
        external_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS
        system_fixture.user_add_ingredient(UID1, "egg")

        mocker.patch.object(external_accessor, "search_recipes_by_ingredients")
        external_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(external_accessor, "get_recipe_info")
        external_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK
        only_egg_results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(only_egg_results) > 0

        system_fixture.user_add_ingredient(UID1, "carrot")
        system_fixture.deselect_user_ingredient(UID1, "carrot")
        deselected_apple_results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients

        assert only_egg_results == deselected_apple_results
        external_accessor.search_recipes_by_ingredients.assert_called_with(
            IngredientCollection([Ingredient("egg")]), number=10, ranking=2)

    def test_search_recipe_no_missing_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        recipe_search = system_fixture.user_search_recipes(UID1)
        results = recipe_search.results(max_missing_ingredients=0)
        assert len(results) == 1
        result_ids = set(res["id"] for res in results)
        assert 1 in result_ids

    def test_search_recipe_one_missing_ingredient(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        recipe_search = system_fixture.user_search_recipes(UID1)
        results = recipe_search.results(max_missing_ingredients=1, min_missing_ingredients=1)
        assert len(results) == 1
        result_ids = set(res["id"] for res in results)
        assert 2 in result_ids

    def test_search_recipe_multiple_missing_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        recipe_search = system_fixture.user_search_recipes(UID1)
        results = recipe_search.results(max_missing_ingredients=sys.maxsize, min_missing_ingredients=2)
        assert len(results) == 2
        result_ids = set(res["id"] for res in results)
        assert 3 in result_ids
        assert 4 in result_ids

    def test_search_recipe_two_or_less_missing_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        recipe_search = system_fixture.user_search_recipes(UID1)
        results = recipe_search.results(max_missing_ingredients=2)
        assert len(results) == 3
        # Results should be sorted by number of missing ingredients
        assert results[0]["id"] == 1
        assert results[1]["id"] == 2
        assert results[2]["id"] == 3

    def test_search_recipe_missing_ingredient_info(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        recipe_search = system_fixture.user_search_recipes(UID1)
        results = recipe_search.results()

        recipe_1 = results[0]
        assert recipe_1["missedIngredientCount"] == 0

        recipe_2 = results[1]
        assert recipe_2["missedIngredientCount"] == 1
        missed_ingredients_2 = recipe_2["missedIngredients"]
        assert missed_ingredients_2[0]["name"] == "baking powder"

        recipe_3 = results[2]
        assert recipe_3["missedIngredientCount"] == 2
        missed_ingredients_3 = set(ingredient["name"] for ingredient in recipe_3["missedIngredients"])
        assert "milk" in missed_ingredients_3
        assert "flour" in missed_ingredients_3

    def test_search_recipe_sorted(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        recipe_search = system_fixture.user_search_recipes(UID1)

        # Missing ingredients
        results = recipe_search.results(key="missedIngredientCount", max_missing_ingredients=3)
        assert len(results) == 4
        assert results[0]["id"] == 1
        assert results[1]["id"] == 2
        assert results[2]["id"] == 3
        assert results[3]["id"] == 4

        # Used ingredients
        results = recipe_search.results(key="usedIngredientCount", max_missing_ingredients=3)
        assert len(results) == 4
        assert results[0]["id"] == 4
        assert results[1]["id"] == 2
        assert results[2]["id"] == 1
        assert results[3]["id"] == 3

        # Prep time
        results = recipe_search.results(key="readyInMinutes", max_missing_ingredients=3)
        assert len(results) == 4
        assert results[0]["id"] == 3
        assert results[1]["id"] == 4
        assert results[2]["id"] == 1
        assert results[3]["id"] == 2

        # Reverse order
        results = recipe_search.results(key="missedIngredientCount", max_missing_ingredients=3, reverse=True)
        assert len(results) == 4
        assert results[0]["id"] == 4
        assert results[1]["id"] == 3
        assert results[2]["id"] == 2
        assert results[3]["id"] == 1


class TestSelectFilter:
    """
    Testing selection/deselection of recipe search filters.
    """

    def test_select_diet_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        assert len(filters.selected["diets"]) == 0
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        assert len(filters.selected["diets"]) == 1
        assert "vegetarian" in filters.selected["diets"]

    def test_deselect_diet_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        assert len(filters.selected["diets"]) == 1
        assert "vegetarian" in filters.selected["diets"]
        system_fixture.deselect_user_filter(UID1, "diets", "vegetarian")
        assert len(filters.selected["diets"]) == 0

    def test_select_cuisine_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        assert len(filters.selected["cuisines"]) == 0
        system_fixture.select_user_filter(UID1, "cuisines", "African")
        assert len(filters.selected["cuisines"]) == 1
        assert "African" in filters.selected["cuisines"]

    def test_deselect_cuisine_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        system_fixture.select_user_filter(UID1, "cuisines", "African")
        assert len(filters.selected["cuisines"]) == 1
        assert "African" in filters.selected["cuisines"]
        system_fixture.deselect_user_filter(UID1, "cuisines", "African")
        assert len(filters.selected["cuisines"]) == 0

    def test_select_meal_type_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        assert len(filters.selected["mealTypes"]) == 0
        system_fixture.select_user_filter(UID1, "mealTypes", "breakfast")
        assert len(filters.selected["mealTypes"]) == 1
        assert "breakfast" in filters.selected["mealTypes"]

    def test_deselect_meal_type_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        system_fixture.select_user_filter(UID1, "mealTypes", "breakfast")
        assert len(filters.selected["mealTypes"]) == 1
        assert "breakfast" in filters.selected["mealTypes"]
        system_fixture.deselect_user_filter(UID1, "mealTypes", "breakfast")
        assert len(filters.selected["mealTypes"]) == 0

    def test_select_unsupported_filter_fails(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        assert len(filters.selected["diets"]) == 0
        with pytest.raises(FilterNotSupportedError):
            system_fixture.select_user_filter(UID1, "diets", "gobblegobble")
        assert len(filters.selected["diets"]) == 0

    def test_deselect_unsupported_filter_fails(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        assert len(filters.selected["diets"]) == 1
        with pytest.raises(FilterNotSupportedError):
            system_fixture.deselect_user_filter(UID1, "diets", "gobblegobble")
        assert len(filters.selected["diets"]) == 1

    def test_select_multiple_filters(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters

        assert len(filters.selected["diets"]) == 0
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        assert len(filters.selected["diets"]) == 1
        assert "vegetarian" in filters.selected["diets"]

        system_fixture.select_user_filter(UID1, "diets", "ketogenic")
        assert len(filters.selected["diets"]) == 2
        assert "vegetarian" in filters.selected["diets"]
        assert "ketogenic" in filters.selected["diets"]

        system_fixture.select_user_filter(UID1, "diets", "glutenFree")
        assert len(filters.selected["diets"]) == 3
        assert "vegetarian" in filters.selected["diets"]
        assert "ketogenic" in filters.selected["diets"]
        assert "glutenFree" in filters.selected["diets"]

    def test_deselect_multiple_filters(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        filters = system_fixture.get_user(UID1).recipe_filters
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        system_fixture.select_user_filter(UID1, "diets", "ketogenic")
        system_fixture.select_user_filter(UID1, "diets", "glutenFree")
        assert len(filters.selected["diets"]) == 3

        system_fixture.deselect_user_filter(UID1, "diets", "vegetarian")
        assert len(filters.selected["diets"]) == 2
        assert "vegetarian" not in filters.selected["diets"]
        assert "ketogenic" in filters.selected["diets"]
        assert "glutenFree" in filters.selected["diets"]

        system_fixture.deselect_user_filter(UID1, "diets", "ketogenic")
        assert len(filters.selected["diets"]) == 1
        assert "ketogenic" not in filters.selected["diets"]
        assert "glutenFree" in filters.selected["diets"]

        system_fixture.deselect_user_filter(UID1, "diets", "glutenFree")
        assert len(filters.selected["diets"]) == 0


class TestFilterRecipeSearch:
    """
    Testing recipe searching with filters applied.
    """

    def test_one_diet_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 2
        recipe_ids = set(result["id"] for result in results)
        assert 1 in recipe_ids
        assert 2 in recipe_ids

    def test_multiple_diet_filters(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        # Ensure results match all filters in AND relationship
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        system_fixture.select_user_filter(UID1, "diets", "ketogenic")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 1
        recipe_ids = set(result["id"] for result in results)
        assert 2 in recipe_ids

        system_fixture.select_user_filter(UID1, "diets", "lowFodmap")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 0

    def test_one_cuisine_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        system_fixture.select_user_filter(UID1, "cuisines", "African")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 1
        recipe_ids = set(result["id"] for result in results)
        assert 3 in recipe_ids

    def test_multiple_cuisine_filters(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        # Ensure results match any of filters in OR relationship
        system_fixture.select_user_filter(UID1, "cuisines", "African")
        system_fixture.select_user_filter(UID1, "cuisines", "German")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 3
        recipe_ids = set(result["id"] for result in results)
        assert 1 in recipe_ids
        assert 3 in recipe_ids
        assert 4 in recipe_ids

    def test_one_meal_type_filter(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        system_fixture.select_user_filter(UID1, "mealTypes", "breakfast")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 1
        recipe_ids = set(result["id"] for result in results)
        assert 2 in recipe_ids

    def test_multiple_meal_type_filters(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        # Ensure results match any of filters in OR relationship
        system_fixture.select_user_filter(UID1, "mealTypes", "breakfast")
        system_fixture.select_user_filter(UID1, "mealTypes", "dessert")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 3
        recipe_ids = set(result["id"] for result in results)
        assert 1 in recipe_ids
        assert 2 in recipe_ids
        assert 4 in recipe_ids

    def test_multiple_filter_categories(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        # Test mixing of AND and OR type filters
        mocker.patch.object(api_accessor, "search_ingredient")
        api_accessor.search_ingredient.return_value = RECIPE_INGREDIENT_RESULTS

        system_fixture.user_add_ingredient(UID1, "egg")
        system_fixture.user_add_ingredient(UID1, "carrot")

        mocker.patch.object(api_accessor, "search_recipes_by_ingredients")
        api_accessor.search_recipes_by_ingredients.return_value = SEARCH_BY_INGREDIENT_RESULTS
        mocker.patch.object(api_accessor, "get_recipe_info")
        api_accessor.get_recipe_info.return_value = RECIPE_INFO_BULK

        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        assert len(results) == 4

        # OR relationship within mealTypes
        system_fixture.select_user_filter(UID1, "mealTypes", "breakfast")
        system_fixture.select_user_filter(UID1, "mealTypes", "dessert")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        recipe_ids = set(result["id"] for result in results)
        assert len(results) == 3
        assert 1 in recipe_ids
        assert 2 in recipe_ids
        assert 4 in recipe_ids

        # OR relationship within cuisines, AND relationship with mealTypes
        system_fixture.select_user_filter(UID1, "cuisines", "British")
        system_fixture.select_user_filter(UID1, "cuisines", "Greek")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        recipe_ids = set(result["id"] for result in results)
        assert len(results) == 2
        assert 1 in recipe_ids
        assert 2 in recipe_ids

        # AND relationship within diets and with other categories
        system_fixture.select_user_filter(UID1, "diets", "vegetarian")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        recipe_ids = set(result["id"] for result in results)
        assert len(results) == 2
        assert 1 in recipe_ids
        assert 2 in recipe_ids

        system_fixture.select_user_filter(UID1, "diets", "ketogenic")
        results = system_fixture.user_search_recipes(UID1).results_sorted_by_missing_ingredients
        recipe_ids = set(result["id"] for result in results)
        assert len(results) == 1
        assert 2 in recipe_ids
