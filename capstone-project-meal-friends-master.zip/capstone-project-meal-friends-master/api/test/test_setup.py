"""
Run all tests from the api/ directory with by running either
    `py.test`
    or
    `python -m pytest test/`
"""

import sys
import os

# add the api/ folder to path so our classes can be imported below

sys.path.append(os.getcwd())

import db_accessor
import internal_accessor
import external_accessor
from user import User
from ingredient_collection import IngredientCollection
from ingredient import Ingredient

UID1 = "uid"
USER1 = User(uid=UID1)

APPLE_RESULTS = IngredientCollection([
    Ingredient("apple", image="apple.jpg"),
    Ingredient("applesauce", image="applesauce.jpg"),
    Ingredient("apple cider vinegar", image="acv.jpg")
])

RECIPE_INGREDIENT_RESULTS = IngredientCollection([
    Ingredient("egg"),
    Ingredient("carrot"),
    Ingredient("milk"),
    Ingredient("flour"),
    Ingredient("apple"),
    Ingredient("potato")
])


def mock_db(mocker):
    mocker.patch.object(db_accessor, "get_user", return_value=None)
    mocker.patch.object(db_accessor, "update_user", return_value=None)
    mocker.patch.object(db_accessor, "get_user_with_google_id", return_value=None)


def reset_user(system_fixture, uid):
    system_fixture.reset_user(uid)


def reset_caches(internal=True, external=True):
    if internal:
        internal_accessor.db_cache.clear()
    if external:
        external_accessor.ingredient_search_cache.clear()
        external_accessor.recipe_search_cache.clear()
        external_accessor.bulk_recipe_search_cache.clear()