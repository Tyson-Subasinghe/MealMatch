"""
Run all tests from the api/ directory with by running either
    `py.test`
    or
    `python -m pytest test/`
"""

import os
import sys

import pytest

# add the api/ folder to path so our classes can be imported below

sys.path.append(os.getcwd())

import api_accessor
from meal_system import MealSystem
from exceptions import NoIngredientError
from test.test_setup import *


@pytest.fixture(scope="function", autouse=True)
def system_fixture() -> MealSystem:
    reset_caches()
    system_fixture = MealSystem()
    return system_fixture


class TestShoppingList:
    def test_add_to_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.add_to_shopping_list(UID1, "applesauce")

        user_details = system_fixture.user_to_dict(UID1)

        shopping_list = user_details["shoppingList"]
        assert len(shopping_list) == 1
        assert shopping_list[0]["name"] == "applesauce"

    def test_add_vf_ingredient_to_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.user_add_ingredient(UID1, "applesauce")
        system_fixture.add_to_shopping_list(UID1, "applesauce")

        user_details = system_fixture.user_to_dict(UID1)

        vf = user_details["ingredients"]
        assert len(vf) == 1
        assert vf[0]["name"] == "apple"

        shopping_list = user_details["shoppingList"]
        assert len(shopping_list) == 1
        assert shopping_list[0]["name"] == "applesauce"

    def test_add_multiple_to_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.add_to_shopping_list(UID1, "applesauce")
        system_fixture.add_to_shopping_list(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "apple cider vinegar")

        user_details = system_fixture.user_to_dict(UID1)

        shopping_list = user_details["shoppingList"]
        assert len(shopping_list) == 3
        assert shopping_list[0]["name"] == "applesauce"
        assert shopping_list[1]["name"] == "apple"
        assert shopping_list[2]["name"] == "apple cider vinegar"

    def test_add_an_ingredient_repeatedly_to_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.add_to_shopping_list(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "applesauce")
        system_fixture.add_to_shopping_list(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "apple cider vinegar")
        system_fixture.add_to_shopping_list(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "applesauce")

        user_details = system_fixture.user_to_dict(UID1)

        shopping_list = user_details["shoppingList"]
        assert len(shopping_list) == 3
        assert shopping_list[0]["name"] == "apple"
        assert shopping_list[1]["name"] == "applesauce"
        assert shopping_list[2]["name"] == "apple cider vinegar"

    def test_remove_from_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.add_to_shopping_list(UID1, "applesauce")
        system_fixture.add_to_shopping_list(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "apple cider vinegar")
        system_fixture.remove_from_shopping_list(UID1, "apple")

        user_details = system_fixture.user_to_dict(UID1)

        shopping_list = user_details["shoppingList"]
        assert len(shopping_list) == 2
        assert shopping_list[0]["name"] == "applesauce"
        assert shopping_list[1]["name"] == "apple cider vinegar"

    def test_selected_ingredients_includes_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        system_fixture.user_add_ingredient(UID1, "apple")
        system_fixture.add_to_shopping_list(UID1, "applesauce")

        search_with = system_fixture.get_user(UID1).selected_ingredients
        assert len(search_with) == 2
        assert "apple" in search_with.names
        assert "applesauce" in search_with.names

    def test_remove_non_existent_ingredient_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        with pytest.raises(NoIngredientError):
            system_fixture.remove_from_shopping_list(UID1, "not-real")

    def test_remove_not_present_ingredient_shopping_list(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)

        with pytest.raises(NoIngredientError):
            system_fixture.remove_from_shopping_list(UID1, "apple")
