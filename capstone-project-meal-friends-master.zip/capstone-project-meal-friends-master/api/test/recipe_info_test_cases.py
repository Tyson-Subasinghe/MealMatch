SEARCH_BY_INGREDIENT_RESULTS = [
    {
        "id": 1,
        "image": "https://e.jpg",
        "imageType": "jpg",
        "likes": 0,
        "missedIngredientCount": 0,
        "missedIngredients": [],
        "title": "Egg and a carrot",
        "unusedIngredients": [],
        "usedIngredientCount": 2,
        "usedIngredients": [
            {
                "aisle": "Produce",
                "amount": 1.0,
                "id": 11,
                "image": "https://egg.jpg",
                "meta": [],
                "name": "egg",
            },
            {
                "aisle": "Produce",
                "amount": 1.0,
                "id": 12,
                "image": "https://scarrot.jpg",
                "meta": [],
                "name": "carrot",
            }
        ]
    },
    {
        "id": 2,
        "image": "https://e.jpg",
        "imageType": "jpg",
        "likes": 0,
        "missedIngredientCount": 1,
        "missedIngredients": [
            {
                "aisle": "Baking",
                "amount": 1.0,
                "id": 18371,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/white-powder.jpg",
                "meta": [],
                "name": "baking powder",
                "original": "1 tsp baking powder",
                "originalName": "baking powder",
                "unit": "tsp",
                "unitLong": "teaspoon",
                "unitShort": "tsp"
            }
        ],
        "title": "Apple Or Peach Strudel",
        "unusedIngredients": [],
        "usedIngredientCount": 1,
        "usedIngredients": [
            {
                "aisle": "Produce",
                "amount": 6.0,
                "id": 9003,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/apple.jpg",
                "meta": [],
                "name": "apples",
                "original": "6 large baking apples",
                "originalName": "baking apples",
                "unit": "large",
                "unitLong": "larges",
                "unitShort": "large"
            }
        ]
    },
    {
        "id": 3,
        "image": "https://spoonacular.com/recipeImages/632660-312x231.jpg",
        "imageType": "jpg",
        "likes": 3,
        "missedIngredientCount": 2,
        "missedIngredients": [
            {
                "aisle": "Milk, Eggs, Other Dairy",
                "amount": 1.5,
                "extendedName": "unsalted butter",
                "id": 1001,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/butter-sliced.jpg",
                "meta": [
                    "unsalted",
                    "cold"
                ],
                "name": "milk",
                "original": "1 1/2 sticks cold unsalted butter cold unsalted butter<",
                "originalName": "cold unsalted butter cold unsalted butter<",
                "unit": "sticks",
                "unitLong": "sticks",
                "unitShort": "sticks"
            },
            {
                "aisle": "Produce",
                "amount": 4.0,
                "id": 1079003,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/red-delicious-apples.png",
                "meta": [
                    "red",
                    " such as golden delicious, peeled, cored and cut into 1/4-inch-thick slices "
                ],
                "name": "flour",
                "original": "4 larges red apples, such as Golden Delicious, peeled, cored and cut into 1/4-inch-thick slices",
                "originalName": "s red apples, such as Golden Delicious, peeled, cored and cut into 1/4-inch-thick slices",
                "unit": "large",
                "unitLong": "larges",
                "unitShort": "large"
            }
        ],
        "title": "Apricot Glazed Apple Tart",
        "unusedIngredients": [
            {
                "aisle": "Produce",
                "amount": 1.0,
                "id": 9003,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/apple.jpg",
                "meta": [],
                "name": "apples",
                "original": "apples",
                "originalName": "apples",
                "unit": "serving",
                "unitLong": "serving",
                "unitShort": "serving"
            }
        ],
        "usedIngredientCount": 3,
        "usedIngredients": []
    },
    {
        "id": 4,
        "image": "https://spoonacular.com/recipeImages/632660-312x231.jpg",
        "imageType": "jpg",
        "likes": 3,
        "missedIngredientCount": 3,
        "missedIngredients": [
            {
                "aisle": "Milk, Eggs, Other Dairy",
                "amount": 1.5,
                "extendedName": "unsalted butter",
                "id": 1001,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/butter-sliced.jpg",
                "meta": [
                    "unsalted",
                    "cold"
                ],
                "name": "milk",
            },
            {
                "image": "https://spoonacular.com/cdn/ingredients_100x100/butter-sliced.jpg",
                "name": "some ingredient"
            },
            {
                "aisle": "Produce",
                "amount": 4.0,
                "id": 1079003,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/red-delicious-apples.png",
                "meta": [
                    "red",
                    " such as golden delicious, peeled, cored and cut into 1/4-inch-thick slices "
                ],
                "name": "potato",
                "original": "4 larges red apples, such as Golden Delicious, peeled, cored and cut into 1/4-inch-thick slices",
                "originalName": "s red apples, such as Golden Delicious, peeled, cored and cut into 1/4-inch-thick slices",
                "unit": "large",
                "unitLong": "larges",
                "unitShort": "large"
            }
        ],
        "title": "Egg carrot milk potato",
        "unusedIngredients": [
            {
                "aisle": "Produce",
                "amount": 1.0,
                "id": 9003,
                "image": "https://spoonacular.com/cdn/ingredients_100x100/apple.jpg",
                "meta": [],
                "name": "apples",
                "original": "apples",
                "originalName": "apples",
                "unit": "serving",
                "unitLong": "serving",
                "unitShort": "serving"
            }
        ],
        "usedIngredientCount": 0,
        "usedIngredients": []
    }
]

RECIPE_INFO_BULK = [
    {
        "id": 1,
        "title": "Hardboiled egg with a carrot",
        "image": "https://image_url.com",
        "readyInMinutes": 45,
        "sourceUrl": "http://recipe.com",
        "cuisines": ["German", "British"],
        "dairyFree": False
        ,
        "diets": [],
        "gaps": "no",
        "glutenFree": True
        ,
        "instructions": "",
        "ketogenic": False
        ,
        "lowFodmap": False
        ,
        "occasions": [],
        "sustainable": False
        ,
        "vegan": False
        ,
        "vegetarian": True
        ,
        "veryHealthy": False
        ,
        "veryPopular": False
        ,
        "whole30": False
        ,
        "dishTypes": [
            "lunch",
            "dessert"
        ],
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {

                "name": "carrot",

            },

        ],
    },
    {
        "id": 2,
        "title": "Hardboiled egg with a carrot and milk",
        "image": "https://image_url.com",
        "readyInMinutes": 60,
        "sourceUrl": "http://recipe.com",
        "cuisines": ["Greek"],
        "dairyFree": False
        ,
        "diets": [],
        "gaps": "no",
        "glutenFree": True
        ,
        "instructions": "",
        "ketogenic": True
        ,
        "lowFodmap": False
        ,
        "occasions": [],
        "sustainable": False
        ,
        "vegan": False
        ,
        "vegetarian": True
        ,
        "veryHealthy": False
        ,
        "veryPopular": False
        ,
        "whole30": False
        ,
        "dishTypes": [
            "breakfast"
        ],
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",
            },
            {
                "name": "milk",
            },

        ],
    },
    {
        "id": 3,
        "title": "Hardboiled egg with a carrot and milk and flour",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "cuisines": ["African"],
        "dairyFree": False
        ,
        "diets": [],
        "gaps": "no",
        "glutenFree": False
        ,
        "instructions": "",
        "ketogenic": False
        ,
        "lowFodmap": False
        ,
        "occasions": [],
        "sustainable": False
        ,
        "vegan": False
        ,
        "vegetarian": False
        ,
        "veryHealthy": False
        ,
        "veryPopular": False
        ,
        "whole30": False
        ,
        "dishTypes": [
        ],
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",
            },
            {
                "name": "milk",
            },
            {
                "name": "flour",
            },

        ],
    },
    {
        "id": 4,
        "title": "Egg carrot milk potato",
        "image": "https://image_url.com",
        "readyInMinutes": 30,
        "sourceUrl": "http://recipe.com",
        "cuisines": ["German"],
        "dairyFree": False
        ,
        "diets": [],
        "gaps": "no",
        "glutenFree": False
        ,
        "instructions": "",
        "ketogenic": False
        ,
        "lowFodmap": False
        ,
        "occasions": [],
        "sustainable": False
        ,
        "vegan": False
        ,
        "vegetarian": False
        ,
        "veryHealthy": False
        ,
        "veryPopular": False
        ,
        "whole30": False
        ,
        "dishTypes": [
            "dessert"
        ],
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",
            },
            {
                "name": "milk",
            },
            {
                "name": "potato",
            },

        ],
    }
]

# For testing exclude ingredients search

RECIPE_INFO_NO_MILK = [
    {
        "id": 1,
        "title": "Hardboiled egg with a carrot",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",

            },

        ],
    }
]

RECIPE_INFO_NO_FLOUR = [
    {
        "id": 1,
        "title": "Hardboiled egg with a carrot",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",

            },

        ],
    },
    {
        "id": 2,
        "title": "Hardboiled egg with a carrot and milk",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",
            },
            {
                "name": "milk",
            },

        ],
    },
    {
        "id": 4,
        "title": "Egg carrot milk potato",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",
            },
            {
                "name": "milk",
            },
            {
                "name": "potato",
            },

        ],
    }
]

RECIPE_INFO_NO_FLOUR_NO_POTATO = [
    {
        "id": 1,
        "title": "Hardboiled egg with a carrot",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",

            },

        ],
    },
    {
        "id": 2,
        "title": "Hardboiled egg with a carrot and milk",
        "image": "https://image_url.com",
        "readyInMinutes": 15,
        "sourceUrl": "http://recipe.com",
        "extendedIngredients": [
            {
                "name": "egg",
            },
            {
                "name": "carrot",
            },
            {
                "name": "milk",
            },

        ],
    }
]

RECIPE_INFO_EMPTY = []