"""
Run all tests from the api/ directory with by running either
    `py.test`
    or
    `python -m pytest test/`
"""

import os
import sys

import pytest

# add the api/ folder to path so our classes can be imported below

sys.path.append(os.getcwd())

import api_accessor
from meal_system import MealSystem
from test.test_setup import *


@pytest.fixture(scope="function", autouse=True)
def system_fixture() -> MealSystem:
    reset_caches()
    system_fixture = MealSystem()
    return system_fixture


class TestLogin:
    def test_login_new_user(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        google_id = "googlyid"
        name = "firstname"
        email = "user1@email.com"
        result = system_fixture.login(UID1, google_id, name, email)
        assert result == UID1

        user = system_fixture.get_user(UID1)
        assert user.profile.google_id == google_id
        assert user.profile.username == name

    def test_login_new_user_retains_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)
        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)
        system_fixture.user_add_ingredient(UID1, "apple")

        google_id = "googlyid"
        name = "firstname"
        email = "user1@email.com"
        result = system_fixture.login(UID1, google_id, name, email)
        assert result == UID1

        user = system_fixture.get_user(UID1)
        assert user.profile.google_id == google_id
        assert user.profile.username == name
        assert len(user.virtual_fridge.names) == 1
        assert "apple" in user.virtual_fridge.names

    def test_login_existing_user(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        google_id = "googlyid"
        name = "firstname"
        email = "user1@email.com"
        system_fixture.login(UID1, google_id, name, email)  # Associates accounts

        result = system_fixture.login("some-disposable-uid", google_id, name, email)

        assert result == UID1
        user = system_fixture.get_user(UID1)
        assert user.profile.google_id == google_id
        assert user.profile.username == name

    def test_login_existing_user_revives_session(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)
        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)
        system_fixture.user_add_ingredient(UID1, "apple")

        google_id = "googlyid"
        name = "firstname"
        email = "user1@email.com"
        system_fixture.login(UID1, google_id, name, email)
        system_fixture.user_add_ingredient(UID1, "applesauce")

        result = system_fixture.login("random-disappearing-uid", google_id, name, email)

        assert result == UID1
        user = system_fixture.get_user(UID1)
        assert user.profile.google_id == google_id
        assert user.profile.username == name
        assert user.profile.email == email
        assert len(user.virtual_fridge.names) == 2
        assert "apple" in user.virtual_fridge.names
        assert "applesauce" in user.virtual_fridge.names
