"""
Run all tests from the api/ directory with by running either
    `py.test`
    or
    `python -m pytest test/`
"""

import os
import sys

import pytest

# add the api/ folder to path so our classes can be imported below

sys.path.append(os.getcwd())

import api_accessor
from meal_system import MealSystem
from test.test_setup import *


@pytest.fixture(scope="function", autouse=True)
def system_fixture() -> MealSystem:
    reset_caches()
    system_fixture = MealSystem()
    return system_fixture

class TestUser:
    """
    This class tests functions in meal_system associated with users
    """

    def test_new_user(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)

        new_uid = system_fixture.new_user()

        new_user = system_fixture.get_user(new_uid)
        assert new_user.uid == new_uid

    def test_create_new_user_if_not_exists_creates_new_user(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)

        new_uid = system_fixture.create_user_if_not_exists(None)

        new_user = system_fixture.get_user(new_uid)
        assert new_user.uid == new_uid

    def test_create_new_user_if_not_exists_finds_existing_user(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)  # Create the user

        found_uid = system_fixture.create_user_if_not_exists(UID1)

        assert found_uid == UID1

    def test_get_user_details_without_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        user_details = system_fixture.user_to_dict(UID1)

        assert user_details["ingredients"] == []

    def test_get_user_details_with_ingredients(self, system_fixture: MealSystem, mocker):
        mock_db(mocker)
        reset_user(system_fixture, UID1)

        mocker.patch.object(api_accessor, "search_ingredient", return_value=APPLE_RESULTS)
        system_fixture.user_add_ingredient(UID1, "applesauce")
        system_fixture.user_add_ingredient(UID1, "apple")

        user_details = system_fixture.user_to_dict(UID1)

        ingredient_details = user_details["ingredients"]
        assert len(ingredient_details) == 2
        # Relying on ingredients maintaining their order
        assert ingredient_details[0]["name"] == "applesauce"
        assert ingredient_details[1]["name"] == "apple"
