from typing import Optional, Dict


class UserProfile:
    def __init__(self, google_id: Optional[str] = None, username: Optional[str] = None, email: Optional[str] = None):
        self.google_id = google_id
        self.username = username  # Currently unused. Keep here to preserve json format
        self.email = email

    def to_dict(self) -> Dict:
        return {
            "googleId": self.google_id,
            "username": self.username,
            "email": self.email
        }

    @classmethod
    def from_dict(cls, data: Optional[Dict] = None) -> "UserProfile":
        if not data:  # None or empty
            return cls()

        google_id = data.get("googleId")
        username = data.get("username")
        email = data.get("email")
        return cls(google_id=google_id, username=username, email=email)

    def __str__(self):
        return f"google ID={self.google_id}. Username={self.username}. Email={self.email}"
