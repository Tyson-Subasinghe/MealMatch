import json
from functools import wraps
from timeit import default_timer as timer
import logging
from typing import Dict

from constants import LOGGING_LEVEL

logging.basicConfig(level=LOGGING_LEVEL)


def log_duration(func):
    """
    Used as a decorator, this will log the time taken for a function to execute
    """
    @wraps(func)
    def wrapping(*args, **kwargs):
        start = timer()
        result = func(*args, **kwargs)
        end = timer()
        millis = (end - start) * 1000
        logging.info(f"{func.__name__} took {millis:.2f}ms")
        return result

    return wrapping


class LogFormat:
    @staticmethod
    def _full(data, *args, **kwargs) -> str:
        return str(data)

    @staticmethod
    def _length(data, *args, **kwargs) -> str:
        return f"with length {len(data)}"

    @staticmethod
    def _short(data, chars, *args, **kwargs) -> str:
        return f"{str(data)[:chars]}..."

    @staticmethod
    def _to_dict(data, *args, **kwargs):
        return data.to_dict()

    @staticmethod
    def _each_dict_field(data: Dict, field, separator, *args, **kwargs) -> str:
        """
        For data in the form:
        [
            { k1: valueA, ... },
            { k1: valueB, ... },
            ...
        ]
        this function can print the value of k1 in each dict. Set field = k1.
        Useful for recipe results.
        """
        return separator.join([str(item[field]) for item in data])

    @staticmethod
    def _pretty_print_json(data, *args, **kwargs):
        """Pretty prints a json-like structure"""
        return str(json.dumps(data, sort_keys=True, indent=2))

    FULL = _full
    LENGTH = _length
    SHORT = _short
    TO_DICT = _to_dict
    EACH_DICT_FIELD = _each_dict_field
    PRETTY_PRINT_JSON = _pretty_print_json


def log_result(formatting=LogFormat.FULL, chars=100, separator="\n ", field="title"):
    """
    This is a decorator which will log the returned value of a function
    in a specified format (such as those in LogFormat).
    It must be called with parentheses i.e. `log_result()` even with no args.
    """
    def _log_result(func):
        @wraps(func)
        def wrapping(*args, **kwargs):
            result = func(*args, **kwargs)
            # Errors might occur e.g. if a dict is expected but not given, or
            # the expected key is not found.
            try:
                logging.info(f"{func.__name__} gave result: "
                             f"{formatting(result, chars=chars, separator=separator, field=field)}")
            except Exception as e:
                logging.error(f"An error occurred while trying to format logs: {e}")
            return result

        return wrapping
    return _log_result
