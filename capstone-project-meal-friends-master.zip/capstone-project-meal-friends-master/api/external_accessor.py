from typing import Optional, Tuple, Dict, List

import api_accessor
from ingredient import Ingredient
from ingredient_collection import IngredientCollection
from timed_cache import TimedCache

ingredient_search_cache = TimedCache()
recipe_search_cache = TimedCache()
bulk_recipe_search_cache = TimedCache()


def search_ingredient(ingredient: str) -> IngredientCollection:
    cached_result = ingredient_search_cache.get(ingredient, None)
    if cached_result:
        return cached_result
    else:
        result = api_accessor.search_ingredient(ingredient)
    ingredient_search_cache[ingredient] = result  # Refresh or set cache pair
    return result


def search_recipes_by_ingredients(ingredients: IngredientCollection, number: int, ranking: int) -> List[Dict]:
    # sort keys to prevent unnecessary cache misses
    search_input = ','.join(name for name in sorted(ingredients.names))
    cache_pattern: Tuple = (number, search_input, ranking)  # since tuple is hashable

    cached_result = recipe_search_cache.get(cache_pattern)
    if cached_result:
        result = cached_result
    else:
        result = api_accessor.search_recipes_by_ingredients(search_input, number=number, ranking=ranking)
    recipe_search_cache[cache_pattern] = result
    return result


def get_recipe_info(ids: str):
    cached_result = bulk_recipe_search_cache.get(ids)
    if cached_result:
        result = cached_result
    else:
        result = api_accessor.get_recipe_info(ids)
    bulk_recipe_search_cache[ids] = result
    return result
