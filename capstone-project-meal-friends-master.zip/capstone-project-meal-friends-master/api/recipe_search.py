from typing import Dict, List

import constants
import external_accessor
from constants import NUM_RECIPES, MINIMISE_MISSING_INGREDIENTS
from user import User
from ingredient_collection import IngredientCollection


class RecipeSearch:
    """
    RecipeSearch is a class to handle searching for recipes and processing of the results.
    A class allows us to store results so we can can apply multiple forms of processing (e.g.
    sorting, filtering) without repeating computation or external API calls unnecessarily.
    """

    def __init__(self,
                 user: User,
                 number: int = NUM_RECIPES,
                 ranking: int = MINIMISE_MISSING_INGREDIENTS):
        self.user = user
        self.recipe_filters = user.recipe_filters
        self.excluded_ingredients = set(user.excluded_ingredients.names)
        self.unsorted_results = self.search(number, ranking)
        self.categorised_results = None

    def results(self, max_missing_ingredients: int = constants.MAX_MISSING_INGREDIENTS, min_missing_ingredients: int = 0, key="missedIngredientCount",
                reverse=False) -> List[Dict]:
        """
        Returns all recipe results with a maximum number of missing ingredients
        """
        # Double inequality checks work in python
        recipes = [recipe for recipe in self.unsorted_results if
                   min_missing_ingredients <= recipe["missedIngredientCount"] <= max_missing_ingredients]
        return self._sort_recipes(recipes, key=key, reverse=reverse)

    @staticmethod
    def _sort_recipes(recipes: List, key="missedIngredientCount", reverse=False):
        return sorted(recipes, key=lambda x: x[key], reverse=reverse)

    @property
    def results_sorted_by_missing_ingredients(self) -> List[Dict]:
        """
        Returns a list of all results sorted by number of missing ingredients (ascending)
        """
        return self._sort_recipes(self.unsorted_results)

    def search(self, number: int, ranking: int) -> List[Dict]:
        """
        Get selected information from recipe search results.
        Ranking is an indicator for whether the search should:
            - maximise used ingredients (=1)
            - minimise unused ingredients (=2)

        Returns:
            [
                {
                    "id": id,
                    "title: title,
                    ...
                },
                ...
            ]

        If there are no selected ingredients, returns an empty dictionary.
        """
        include_ingredients = self.user.selected_ingredients
        if len(include_ingredients) == 0:
            return []
        results = self._search_by_ingredients(include_ingredients, number, ranking)
        results = self._process_recipe_info(results)
        return list(results.values())

    def _search_by_ingredients(self, ingredients: IngredientCollection, number: int, ranking) -> Dict[int, Dict]:
        """
        Search for recipes by ingredients using sp.search_recipes_by_ingredients API call.
        Do all search result processing involving missing and/or used ingredients here, as fields like
        "missedIngredientCount" and "missedIngredients" are returned exclusively by this call.

        Returns a dictionary of result info indexed by recipe_id.
        """
        search_by_ingredients_results = external_accessor.search_recipes_by_ingredients(ingredients,
                                                                                        number=number,
                                                                                        ranking=ranking)
        final_results = {}

        for recipe in search_by_ingredients_results:
            if self.recipe_contains_excluded_ingredients(recipe):
                continue
            recipe_id = recipe["id"]
            final_results[recipe_id] = {
                "title": recipe["title"],
                # Upscale small 312x231 images from Spoonacular
                "image": recipe["image"].replace("312x231", constants.RECIPE_IMAGE_SIZE),
                "usedIngredientCount": int(recipe["usedIngredientCount"]),
                "usedIngredients": [{
                    "name": ingredient["name"],
                    "image": ingredient["image"]
                } for ingredient in recipe["usedIngredients"]],
                "missedIngredientCount": int(recipe["missedIngredientCount"]),
                "missedIngredients": [{
                    "name": ingredient["name"],
                    "image": ingredient["image"]
                } for ingredient in recipe["missedIngredients"]]
            }

        return final_results

    def _process_recipe_info(self, results: Dict[int, Dict]) -> Dict[int, Dict]:
        """
        Get extended recipe info using sp.get_recipe_information_bulk API call.
        Source URL and diet/meal-type information is found and processed here.

        results: Dictionary of results from a recipe search (e.g. _search_by_ingredients)

        Returns a dictionary of result info indexed by recipe_id.
        """
        recipe_ids = ','.join(str(_id) for _id in results.keys())
        recipe_info_list = external_accessor.get_recipe_info(recipe_ids)

        # New dict for results that pass filters
        new_results = {}
        for recipe_info in recipe_info_list:
            if not self.recipe_passes_filters(recipe_info):
                continue
            recipe_id = recipe_info["id"]
            new_results[recipe_id] = results[recipe_id]
            new_results[recipe_id].update({
                "id": recipe_id,
                "readyInMinutes": int(recipe_info["readyInMinutes"]),
                "sourceUrl": recipe_info["sourceUrl"]
            })

        return new_results

    def recipe_passes_filters(self, recipe_info) -> bool:
        """
        See if a particular recipe passes the user's filters.

        recipe_info: A dictionary of recipe info as returned by external_accessor.get_recipe_info().
        """
        return self.recipe_filters.passes(recipe_info)

    def recipe_contains_excluded_ingredients(self, recipe_result) -> bool:
        """
        See if a particular recipe contains any of the user's excluded ingredients.

        Recipe results present the required ingredients in two categories - "missedIngredients" and "usedIngredients".
        Since a user cannot have an excluded ingredient in their virtual fridge, there shouldn't be any excluded
        ingredients in "usedIngredients", so we only need to check "missedIngredients".

        recipe_result: A dictionary of recipe result returned by external_accessor.search_recipes_by_ingredients().
        """
        missed_ingredients = set(ingredient["name"] for ingredient in recipe_result["missedIngredients"])
        return len(missed_ingredients.intersection(self.excluded_ingredients)) > 0
