import spoonacular as sp

from constants import SPOONACULAR_API_KEY
from ingredient_collection import IngredientCollection
from logging_tools import log_duration, log_result, LogFormat

sp_api = sp.API(SPOONACULAR_API_KEY)

"""
After each API call, check whether the response was successful or not
using the .raise_for_status() function. We don't want to cache failed responses.
"""


@log_result()
@log_duration
def search_ingredient(ingredient: str) -> IngredientCollection:
    response = sp_api.autocomplete_ingredient_search(ingredient)
    response.raise_for_status()
    ingredient_results = response.json()
    return IngredientCollection.from_dicts(ingredient_results)


@log_result(formatting=LogFormat.EACH_DICT_FIELD, field="missedIngredientCount", separator=", ")
@log_result(formatting=LogFormat.EACH_DICT_FIELD, field="title")
@log_duration
def search_recipes_by_ingredients(ingredients: str, number, ranking):
    response = sp_api.search_recipes_by_ingredients(ingredients,
                                                    number=number,
                                                    ranking=ranking)
    response.raise_for_status()
    return response.json()


@log_result(formatting=LogFormat.EACH_DICT_FIELD, field="title")
@log_duration
def get_recipe_info(ids: str):
    response = sp_api.get_recipe_information_bulk(ids)
    response.raise_for_status()
    return response.json()


if __name__ == "__main__":
    res = search_ingredient("appl")
    print(res)
