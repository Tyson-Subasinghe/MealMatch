from routes import app

app.run()
