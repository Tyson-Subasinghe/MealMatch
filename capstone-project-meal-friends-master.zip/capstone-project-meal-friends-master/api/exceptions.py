class NoIngredientError(Exception):
    pass


class MissingArgError(Exception):
    pass


class FilterNotSupportedError(Exception):
    pass


class FilterCategoryNotSupportedError(Exception):
    pass


class AuthenticationError(Exception):
    pass


class LogoutError(Exception):
    pass


class UserError(Exception):
    pass
