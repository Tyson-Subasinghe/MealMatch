from dotenv import load_dotenv
import logging
import os

from ingredient import Ingredient

load_dotenv()
FLASK_SESSION_SECRET_KEY = os.getenv("SECRET_KEY")
SPOONACULAR_API_KEY = os.getenv("SPOONACULAR_API")
ENVIRONMENT = os.getenv("ENVIRONMENT")
LOGGING_LEVEL = logging.INFO
GOOGLE_CLIENT_ID = "1050549738006-6ml227scfha8rcdb1403of2shmhj34tl.apps.googleusercontent.com"
RECIPE_IMAGE_SIZE = "556x370"

GMAIL_USERNAME = os.getenv("GMAIL_USERNAME")
GMAIL_PASSWORD = os.getenv("GMAIL_PASSWORD")

INGREDIENT_IMAGE_SIZE = "500x500"
SPOONACULAR_BASE_URL = "https://spoonacular.com"
INGREDIENT_IMAGE_SIZE_URL = f"{SPOONACULAR_BASE_URL}/cdn/ingredients_{INGREDIENT_IMAGE_SIZE}"

# 40 minutes cache currently. Max value is 60 mins as per spoony terms of service.
CACHE_TTL_SECONDS = 2400
CACHE_MAX_SIZE = 40  # Can be greatly increased

MAX_MISSING_INGREDIENTS = 3

# Used for spoonacular search_recipes_by_ingredients API.
# ranking=1 maximises used ingredients. ranking=2 minimises missing ingredients.
MAXIMISE_USED_INGREDIENTS = 1
MINIMISE_MISSING_INGREDIENTS = 2

NUM_RECIPES = 15  # Best set to a multiple of 3 (since we have 3 columns)
STARTER_INGREDIENT_SUGGESTIONS = [
    Ingredient("egg", "egg.png"),
    Ingredient("cheese", "cheddar-cheese.png"),
    Ingredient("milk", "milk.jpg"),
    Ingredient("flour", "flour.png"),
    Ingredient("potato", "potatoes-yukon-gold.png")
]
