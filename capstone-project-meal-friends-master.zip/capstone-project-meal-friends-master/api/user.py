import uuid
from typing import Dict, Optional, List

import external_accessor
from exceptions import NoIngredientError
from ingredient import Ingredient
from ingredient_collection import IngredientCollection
from recipe_filters import RecipeFilters
from user_profile import UserProfile


class User:

    def __init__(self,
                 uid: str = None,
                 profile: UserProfile = None,
                 ingredients: IngredientCollection = None,
                 excluded_ingredients: IngredientCollection = None,
                 shopping_list: IngredientCollection = None,
                 recipe_filters: RecipeFilters = None,
                 ingredient_suggestions: IngredientCollection = None):
        # Produce a long random string for each user. It gets stored in the
        # session cookie to identify users temporarily even without login.
        self.uid = uid if uid else str(uuid.uuid4())
        self.profile = profile if profile else UserProfile()
        self.virtual_fridge = ingredients if ingredients else IngredientCollection()
        self.excluded_ingredients = excluded_ingredients if excluded_ingredients else IngredientCollection()
        self.shopping_list = shopping_list if shopping_list else IngredientCollection()
        self.recipe_filters = recipe_filters if recipe_filters else RecipeFilters()
        self.ingredient_suggestions = ingredient_suggestions if ingredient_suggestions else IngredientCollection()

    @classmethod
    def from_dict(cls, user_data: Dict) -> "User":
        """
        Constructs a user object using the output of to_dict
        """
        uid = user_data["uid"]
        profile = UserProfile.from_dict(user_data.get("profile"))
        virtual_fridge = IngredientCollection.from_dicts(user_data.get("ingredients", []))
        excluded_ingredients = IngredientCollection.from_dicts(user_data.get("excludedIngredients", []))
        shopping_list = IngredientCollection.from_dicts(user_data.get("shoppingList", []))
        recipe_filters = RecipeFilters.from_dict(user_data.get("filters", {}))
        ingredient_suggestions = IngredientCollection.from_dicts(user_data.get("ingredientSuggestions", []))

        return cls(uid=uid,
                   profile=profile,
                   ingredients=virtual_fridge,
                   excluded_ingredients=excluded_ingredients,
                   shopping_list=shopping_list,
                   recipe_filters=recipe_filters,
                   ingredient_suggestions=ingredient_suggestions)

    def to_dict(self, include_uid: bool = True) -> Dict:
        """
        Produces a json-like dictionary that represents all aspects of this user
        except for uid, which is a key to find the user.
        NOTE: We don't want to return the uid to the front end, but it's good to have
        in the dict for easy database access.
        """
        data = {
            "profile": self.profile.to_dict(),
            "ingredients": self.virtual_fridge.to_dicts(),
            "excludedIngredients": self.excluded_ingredients.to_dicts(selected_field=False),
            "shoppingList": self.shopping_list.to_dicts(selected_field=False),
            "filters": self.recipe_filters.to_dict(),
            "ingredientSuggestions": self.ingredient_suggestions.to_dicts(selected_field=False)
        }
        if include_uid:
            data["uid"] = self.uid
        return data

    def __str__(self):
        return f"{self.uid[:6]} has\n " \
               f"- ingredients: {str(self.virtual_fridge)} \n " \
               f"- exclusions: {str(self.excluded_ingredients)} \n" \
               f"- shopping: {str(self.shopping_list)} \n" \
               f"- profile: {str(self.profile)}" \
               f"- suggestions: {str(self.ingredient_suggestions)}"

    def search_ingredient(self, ingredient: str):
        """
        Searches for an ingredient.
        Returns all results except the ones that the user has already added.
        """
        ingredients_found = external_accessor.search_ingredient(ingredient)
        return ingredients_found - self.virtual_fridge - self.excluded_ingredients - self.shopping_list

    def filters_to_dict(self) -> Dict:
        """
        Produces a json-like dictionary of a user's filters and their selected state.
        """
        return self.recipe_filters.to_dict()

    # VF functions

    def add_to_virtual_fridge(self, ingredient: str) -> None:
        # Always assume the ingredient name is valid. Spoonacular has some
        # internal inconsistencies. e.g. "tequila" is a recipe ingredient
        # but searching for "tequila" as an ingredient gives 0 results.

        # If the ingredient exists elsewhere, remove it before adding to shopping list
        self._try_remove_ingredient(self.excluded_ingredients, ingredient)
        self._try_remove_ingredient(self.shopping_list, ingredient)

        self.virtual_fridge.add(Ingredient(ingredient))

    def remove_from_virtual_fridge(self, ingredient: str) -> None:
        self.virtual_fridge.remove(Ingredient(ingredient))

    def deselect_ingredient(self, ingredient: str) -> None:
        self.virtual_fridge.deselect_ingredient(Ingredient(ingredient))

    def select_ingredient(self, ingredient: str) -> None:
        self.virtual_fridge.select_ingredient(Ingredient(ingredient))

    # Excluded ingredient functions

    def exclude_ingredient(self, ingredient: str) -> None:
        # Always assume the ingredient name is valid as per comment
        # in self.add_to_virtual_fridge()

        # If the ingredient exists elsewhere, remove it before adding to shopping list
        self._try_remove_ingredient(self.virtual_fridge, ingredient)
        self._try_remove_ingredient(self.shopping_list, ingredient)

        self.excluded_ingredients.add(Ingredient(ingredient))

    def remove_excluded_ingredient(self, ingredient: str) -> None:
        self.excluded_ingredients.remove(Ingredient(ingredient))

    # Shopping list functions

    def add_to_shopping_list(self, ingredient: str) -> None:
        # Always assume the ingredient name is valid as per comment
        # in self.add_to_virtual_fridge()

        # If the ingredient exists elsewhere, remove it before adding to shopping list
        self._try_remove_ingredient(self.virtual_fridge, ingredient)
        self._try_remove_ingredient(self.excluded_ingredients, ingredient)

        self.shopping_list.add(Ingredient(ingredient))

    def remove_from_shopping_list(self, ingredient: str) -> None:
        self.shopping_list.remove(Ingredient(ingredient))

    # Other ingredient functions

    def suggest_ingredient(self) -> Optional[Ingredient]:
        """
        Returns the next suggested ingredient (if any), otherwise None.
        """
        self.ingredient_suggestions = self.ingredient_suggestions - self.all_ingredients
        return self.ingredient_suggestions.pop(0) if self.ingredient_suggestions else None

    def add_ingredient_suggestions(self, recipe_results: List[Dict]) -> None:
        """
        Prepends the given ingredients to the user's ingredient suggestions.
        We want the most relevant ingredients first.

        recipe_results: A list of recipe data with prioritised recipes first.
        In most cases, prioritised recipes are the ones with fewer missing ingredients.
        """
        missing_ingredients = IngredientCollection()

        for result in recipe_results:
            missing_ingredients_data = list(result["missedIngredients"])
            for missing_ingredient in missing_ingredients_data:
                ingredient = Ingredient.from_dict(missing_ingredient)
                missing_ingredients.add(ingredient)

        self.ingredient_suggestions = missing_ingredients + self.ingredient_suggestions

    @staticmethod
    def _try_remove_ingredient(collection: IngredientCollection, ingredient: str):
        try:
            collection.remove(Ingredient(ingredient))
        except NoIngredientError:
            pass

    @property
    def selected_ingredients(self) -> IngredientCollection:
        """
        Selected VF ingredients and shopping list should both be used for recipe searches
        """
        return self.virtual_fridge.selected + self.shopping_list

    @property
    def all_ingredients(self) -> IngredientCollection:
        return self.virtual_fridge + self.excluded_ingredients + self.shopping_list

    # Filter functions

    def select_filter(self, category_name: str, filter_name: str):
        self.recipe_filters.select_filter(category_name, filter_name)

    def deselect_filter(self, category_name: str, filter_name: str):
        self.recipe_filters.deselect_filter(category_name, filter_name)
