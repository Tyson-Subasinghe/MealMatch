from typing import Optional

import db_accessor
from exceptions import UserError
from timed_cache import TimedCache

from user import User

"""
Refer to db_accessor.py for information about connecting to the database.
"""

db_cache = TimedCache()


def get_user(uid: Optional[str]) -> Optional[User]:
    if uid is None:  # Skip the DB access if uid is definitely invalid
        return None

    cached_user = db_cache.get(uid)  # Either User or None
    if cached_user:
        user = cached_user
    else:
        user_data = db_accessor.get_user(uid)  # Returns user_data dict
        if user_data is None:
            user = None
        else:
            user = User.from_dict(user_data)

    if user:
        db_cache[uid] = user  # Refresh the cache timer for this user
    return user


def update_user(user: User) -> None:
    uid = user.uid
    user_data = user.to_dict(include_uid=True)
    db_accessor.update_user(uid, user_data)
    db_cache[uid] = user


def get_user_with_google_id(google_id: str) -> Optional[User]:
    cached_user = _get_cached_user_with_google_id(google_id)

    if cached_user:
        user = cached_user
    else:
        # Need to have exactly 1 result
        user_data = db_accessor.get_user_with_google_id(google_id)
        if user_data is None:
            user = None
        elif len(user_data) > 1:
            raise UserError(f"Expected one user with google id={google_id} "
                            f"but got {len(user_data)}:\n {user_data}")
        else:
            user = User.from_dict(list(user_data.values())[0])  # Nested data

    if user:
        db_cache[user.uid] = user
    return user


def _get_cached_user_with_google_id(google_id: str) -> Optional[User]:
    user: User
    for user in db_cache.values():
        try:
            user_google_id = user.profile.google_id
        except AttributeError:  # If "user" is not of type User or does not have a profile
            continue
        if user_google_id == google_id:
            return user

    return None
