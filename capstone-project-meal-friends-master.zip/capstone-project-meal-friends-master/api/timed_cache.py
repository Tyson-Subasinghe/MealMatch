from cachetools import TTLCache

from constants import CACHE_TTL_SECONDS, CACHE_MAX_SIZE


class TimedCache(TTLCache):
    """
    This class exists to provide easy initial default TTLCache values and to
    log durations when needed.
    """

    def __init__(self, maxsize=CACHE_MAX_SIZE, ttl=CACHE_TTL_SECONDS):
        super().__init__(maxsize=maxsize, ttl=ttl)

    # @log_duration
    def __getitem__(self, *args, **kwargs):
        return super().__getitem__(*args, **kwargs)

    # @log_duration
    def __setitem__(self, *args, **kwargs):
        return super(TimedCache, self).__setitem__(*args, **kwargs)

    # @log_duration
    def get(self, *args, **kwargs):
        return super().get(*args, **kwargs)
