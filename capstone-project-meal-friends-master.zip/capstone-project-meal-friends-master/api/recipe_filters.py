from exceptions import FilterNotSupportedError, FilterCategoryNotSupportedError
from typing import Dict, List, Set

"""
Filter categories and supported values for each filter type are specified by Spoonacular. 
Please see https://spoonacular.com/food-api/docs for more information.
"""

SUPPORTED_DIETS = {
    "glutenFree", "ketogenic", "lowFodmap", "vegan", "vegetarian", "whole30"
}

SUPPORTED_CUISINES = {
    "African", "American", "British", "Cajun", "Caribbean", "Chinese", "Eastern European", "European", "French",
    "German", "Greek", "Indian", "Irish", "Italian", "Japanese", "Jewish", "Korean", "Latin American", "Mediterranean",
    "Mexican", "Middle Eastern", "Nordic", "Southern", "Spanish", "Thai", "Vietnamese"
}

SUPPORTED_MEAL_TYPES = {
    "main course", "side dish", "dessert", "appetizer", "salad", "bread", "breakfast", "soup", "beverage", "sauce",
    "marinade", "fingerfood", "snack", "drink"
}

FILTER_CATEGORIES = {
    "diets": SUPPORTED_DIETS,
    "cuisines": SUPPORTED_CUISINES,
    "mealTypes": SUPPORTED_MEAL_TYPES
}


class RecipeFilters:
    """
    RecipeFilters class maintains the selection state (True or False) of every filter.
    Common logic is abstracted while maintaining the distinction between filter categories as specified by Spoonacular.

    If new categories are added, extra logic is required only for 'passes_filters()' and associated helpers.
    Everything else handles any number of categories automatically.
    """

    def __init__(self):
        """
        A filter is 'selected' if it is in the set for its category.
        Initially all filters are false, so the sets are empty.

        self.categories =
            Dict[category_name, Set[filter_name]]:

            {
                "diets": set(),
                "cuisines": set(),
                "mealTypes": set()
            }
        """
        self.selected = {
            category_name: set() for category_name in FILTER_CATEGORIES.keys()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, List]) -> "RecipeFilters":
        recipe_filters = cls()

        diets = data.get("diets", [])
        cuisines = data.get("cuisines", [])
        meal_types = data.get("mealTypes", [])

        for diet in diets:
            if diet["selected"]:
                recipe_filters.select_filter("diets", diet["name"])
        for cuisine in cuisines:
            if cuisine["selected"]:
                recipe_filters.select_filter("cuisines", cuisine["name"])
        for meal_type in meal_types:
            if meal_type["selected"]:
                recipe_filters.select_filter("mealTypes", meal_type["name"])

        return recipe_filters

    def to_dict(self) -> Dict[str, List[Dict]]:
        """
        Returns a representation of all supported filters, and whether they are selected by the user or not.

        Returns:
            {
                "diets": [
                    {"name": diet1, "selected": true},
                    {"name": diet2, "selected": false},
                    ...
                ],
                "cuisines": [
                    {"name": cuisine1, "selected": true},
                    {"name": cuisine2, "selected": false},
                    ...
                ],
                "mealTypes": [
                    {"name": mealType1, "selected": true},
                    {"name": mealType2, "selected": false},
                    ...
                ]
            }
        """
        return {
            category_name: self._category_to_dict(category_name) for category_name in FILTER_CATEGORIES.keys()
        }

    def _category_to_dict(self, category_name: str) -> List[Dict]:
        """
        Returns:
            List of dictionaries:
            [
                {"name": filter_name, "selected": bool},
                ..
            ]
        """
        return [
            {
                "name": filter_name,
                "selected": self.is_selected(filter_name, category_name)
            }
            for filter_name in self.supported_filters(category_name)
        ]

    def supported_filters(self, category_name: str) -> Set[str]:
        supported_filters = FILTER_CATEGORIES.get(category_name, None)
        if supported_filters is None:
            raise FilterCategoryNotSupportedError(f'"{category_name}" not a supported filter category.')
        return supported_filters

    def select_filter(self, category_name: str, filter_name: str):
        if filter_name not in self.supported_filters(category_name):
            raise FilterNotSupportedError(f'"{filter_name}" not in supported {category_name}.')
        else:
            self.selected[category_name].add(filter_name)

    def deselect_filter(self, category_name: str, filter_name: str):
        if filter_name not in self.supported_filters(category_name):
            raise FilterNotSupportedError(f'"{filter_name}" not in supported {category_name}.')
        else:
            self.selected[category_name].discard(filter_name)

    def passes(self, recipe_info) -> bool:
        """
        See if a particular recipe passes a user's filters.
        If no filters have been selected in any category, everything will pass.

        recipe_info: A dictionary of recipe info as returned by external_accessor.get_recipe_info().
        """

        return self._passes_diets(recipe_info) and \
               self._passes_cuisines(recipe_info) and \
               self._passes_meal_types(recipe_info)

    def _passes_diets(self, recipe_info) -> bool:
        """
        A recipe passes this if it fits all diets (logical AND relationship), i.e. if there are two diets,
        diet1 and diet2, recipe_info will pass this filter only if it belongs to diet1 AND diet2.

        Diets have their own field in a recipe_info dictionary.
        """
        if not self.category_has_selected("diets"):
            return True

        for diet in self.selected.get("diets"):
            diet_found = recipe_info.get(diet, False)
            if not diet_found:
                return False
        return True

    def _passes_cuisines(self, recipe_info) -> bool:
        """
        A recipe passes this if it fits any of the cuisines (logical OR relationship).
        If no cuisine filters are selected, all results are returned as true.

        Cuisines are a list in the 'cuisines' field of a recipe_info dictionary.
        """
        return self._passes_OR_filter(recipe_info, "cuisines", "cuisines")

    def _passes_meal_types(self, recipe_info) -> bool:
        """
        A recipe passes this if it fits any of the meal types (logical OR relationship).
        If no meal types filters are selected, all results are returned as true.

        Meal types are a list in the 'dishTypes' field of a recipe_info dictionary.
        """
        return self._passes_OR_filter(recipe_info, "dishTypes", "mealTypes")

    def _passes_OR_filter(self, recipe_info, recipe_info_filter_name: str, category_name: str) -> bool:
        if not self.category_has_selected(category_name):
            return True

        selected_filters = self.selected.get(category_name)
        recipe_info_filters = set(recipe_info[recipe_info_filter_name])
        for _filter in selected_filters:
            if _filter in recipe_info_filters:
                return True
        return False

    @property
    def no_filters_selected(self) -> bool:
        for filter_set in self.selected.values():
            if len(filter_set) > 0:
                return False
        return True

    def category_has_selected(self, category_name: str) -> bool:
        return len(self.selected[category_name]) > 0

    def is_selected(self, filter_name: str, category_name: str) -> bool:
        return filter_name in self.selected[category_name]
