from typing import Dict, List

from exceptions import NoIngredientError
from ingredient import Ingredient


class IngredientCollection:
    """
    Keeping just a standard list of ingredients becomes unwieldy because
    there are so many operations/checks to run.
    Use this class any time you think of making a list or set of Ingredient objects.

    List is used instead of set as it preserves order and handles mutable objects.
    """

    def __init__(self, ingredients: List[Ingredient] = None):
        """
        Takes a list/set of Ingredient objects
        """
        if ingredients is None:
            self.ingredients = []
        else:
            self.ingredients = ingredients

    @classmethod
    # The Ingredients class isn't fully defined yet so it must be in quotes
    def from_dicts(cls, ingredient_dicts: List[Dict]) -> "IngredientCollection":
        """
        Takes a list of dicts describing Ingredient objects
        """
        ingredient_list = [Ingredient.from_dict(ingredient_dict) for ingredient_dict in ingredient_dicts]
        return cls(ingredient_list)

    def to_dicts(self, selected_field=True) -> List[Dict]:
        return [ingredient.to_dict(selected_field) for ingredient in self.ingredients]

    # The Ingredients class isn't defined so must put it in quotes
    def __sub__(self, other: "IngredientCollection") -> "IngredientCollection":
        return IngredientCollection([ingredient for ingredient in self.ingredients if ingredient not in other])

    # The Ingredients class isn't defined so must put it in quotes
    def __add__(self, other: "IngredientCollection") -> "IngredientCollection":
        existing = set(self.ingredients)  # Use set for efficiency
        result = self.ingredients.copy()
        for ingredient in other.ingredients:
            if ingredient not in existing:
                result.append(ingredient)
        return IngredientCollection(result)

    def __str__(self):
        return f"IngredientCollection: {str([ingredient.name for ingredient in self.ingredients])}"

    def __len__(self):
        return len(self.ingredients)

    def __getitem__(self, item):
        return self.ingredients[item]

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return sorted(self.names) == sorted(other.names)

    def add(self, new: Ingredient) -> None:
        # Adding an existing ingredient will just select it (shouldn't ever happen)
        if new in self.ingredients:
            self.select_ingredient(new)
        else:
            self.ingredients.append(new)

    def remove(self, ingredient: Ingredient) -> None:
        if ingredient in self.ingredients:
            self.ingredients.remove(ingredient)
        else:
            raise NoIngredientError(f"No ingredient named {ingredient.name} in {self.names}")

    def pop(self, index: int = 0):
        """
        Removes and returns the ingredient at the given index.
        Uses default index 0, unlike list which uses the last element.
        """
        if not self.ingredients:
            raise NoIngredientError(f"Cannot pop from the ingredient collection: "
                                    f"{str(self.ingredients)}")
        return self.ingredients.pop(index)

    @property
    def names(self) -> List[str]:
        return [ingredient.name for ingredient in self.ingredients]

    @property
    def selected(self) -> "IngredientCollection":  # The Ingredients class isn't defined so must put it in quotes
        return IngredientCollection([ingredient for ingredient in self.ingredients if ingredient.selected])

    def deselect_ingredient(self, ingredient: Ingredient) -> None:
        ingredient = self.get_ingredient(ingredient)
        ingredient.deselect()

    def select_ingredient(self, ingredient: Ingredient) -> None:
        ingredient = self.get_ingredient(ingredient)
        ingredient.select()

    def get_ingredient(self, ingredient_to_find: Ingredient) -> Ingredient:
        for ingredient in self.ingredients:
            if ingredient == ingredient_to_find:
                return ingredient

        raise NoIngredientError(f"Could not find '{ingredient_to_find.name}' in {str(self.names)}")
