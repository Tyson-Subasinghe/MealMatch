from typing import Dict, Union, Optional, List
import internal_accessor
from constants import STARTER_INGREDIENT_SUGGESTIONS, MAXIMISE_USED_INGREDIENTS
from exceptions import NoIngredientError
from ingredient import Ingredient
from ingredient_collection import IngredientCollection
from user import User
from recipe_search import RecipeSearch


class MealSystem:
    """
    This remains a class just in case it requires attributes again in future.
    It also means we don't have to re-write tests again.
    """

    def create_user_if_not_exists(self, uid: Union[str, None]) -> str:
        user = internal_accessor.get_user(uid)  # Returns None if does not exist
        if user is None:
            uid = self.new_user()
        return uid

    def new_user(self) -> str:
        # Must give new users explicit ingredient suggestions
        user = User(ingredient_suggestions=IngredientCollection(STARTER_INGREDIENT_SUGGESTIONS))
        internal_accessor.update_user(user)
        return user.uid

    def reset_user(self, uid):
        # Must give new users explicit ingredient suggestions
        user = User(uid, ingredient_suggestions=IngredientCollection(STARTER_INGREDIENT_SUGGESTIONS))
        internal_accessor.update_user(user)

    def login(self, uid: str, google_id: str, name: str, email: str) -> str:  # Return uid
        user = internal_accessor.get_user_with_google_id(google_id)

        if user is None:  # First login. Associate with current session
            print(f"First login for {google_id}")
            user = internal_accessor.get_user(uid)
            user.profile.google_id = google_id

        # Update name in case it's changed
        user.profile.username = name
        user.profile.email = email
        
        internal_accessor.update_user(user)
        uid = user.uid
        return uid

    def user_to_dict(self, uid: str) -> Dict:
        return self.get_user(uid).to_dict(include_uid=False)

    def get_user(self, uid: str) -> Optional[User]:
        return internal_accessor.get_user(uid)

    def user_filters_to_dict(self, uid: str) -> Dict:
        user = internal_accessor.get_user(uid)
        return user.recipe_filters.to_dict()

    def user_add_ingredient(self, uid: str, ingredient_to_add: str) -> None:
        user = internal_accessor.get_user(uid)
        user.add_to_virtual_fridge(ingredient_to_add)
        internal_accessor.update_user(user)

    def user_remove_ingredient(self, uid: str, ingredient_to_remove: str) -> None:
        user = internal_accessor.get_user(uid)
        user.remove_from_virtual_fridge(ingredient_to_remove)
        internal_accessor.update_user(user)

    def user_remove_ingredients(self, uid: str, ingredients: List[str]) -> None:
        user = internal_accessor.get_user(uid)
        for ingredient in ingredients:
            user.remove_from_virtual_fridge(ingredient)
        internal_accessor.update_user(user)

    def user_search_ingredient(self, uid: str, ingredient: str) -> IngredientCollection:
        """
        Searches for an ingredient.
        Returns all results except those that the user has already added.
        """
        user = internal_accessor.get_user(uid)
        return user.search_ingredient(ingredient)

    def deselect_user_ingredient(self, uid, ingredient_name: str) -> None:
        user = internal_accessor.get_user(uid)
        user.deselect_ingredient(ingredient_name)
        internal_accessor.update_user(user)

    def select_user_ingredient(self, uid, ingredient_name: str) -> None:
        user = internal_accessor.get_user(uid)
        user.select_ingredient(ingredient_name)
        internal_accessor.update_user(user)

    def user_search_recipes(self, uid: str) -> RecipeSearch:
        """
        Returns a RecipeSearch object for handling search
        """
        user = internal_accessor.get_user(uid)
        search = RecipeSearch(user)
        # Take the opportunity to update ingredient suggestions. Prefer a high limit.
        user.add_ingredient_suggestions(search.results(max_missing_ingredients=10))
        internal_accessor.update_user(user)
        return search

    def user_exclude_ingredient(self, uid, ingredient: str):
        user = internal_accessor.get_user(uid)
        user.exclude_ingredient(ingredient)
        internal_accessor.update_user(user)

    def user_remove_excluded_ingredient(self, uid, ingredient: str):
        user = internal_accessor.get_user(uid)
        user.remove_excluded_ingredient(ingredient)
        internal_accessor.update_user(user)

    def select_user_filter(self, uid: str, category_name: str, filter_name: str):
        user = internal_accessor.get_user(uid)
        user.select_filter(category_name, filter_name)
        internal_accessor.update_user(user)

    def deselect_user_filter(self, uid: str, category_name: str, filter_name: str):
        user = internal_accessor.get_user(uid)
        user.deselect_filter(category_name, filter_name)
        internal_accessor.update_user(user)

    def is_user_logged_in(self, uid: str) -> bool:
        user = internal_accessor.get_user(uid)
        return bool(user.profile.google_id)

    def add_to_shopping_list(self, uid, ingredient):
        user = internal_accessor.get_user(uid)
        user.add_to_shopping_list(ingredient)
        internal_accessor.update_user(user)

    def remove_from_shopping_list(self, uid, ingredient):
        user = internal_accessor.get_user(uid)
        user.remove_from_shopping_list(ingredient)
        internal_accessor.update_user(user)

    def suggest_ingredient(self, uid: str) -> Ingredient:
        user = internal_accessor.get_user(uid)
        result = user.suggest_ingredient()
        if result:
            internal_accessor.update_user(user)
            return result

        recipe_results = RecipeSearch(user, ranking=MAXIMISE_USED_INGREDIENTS).results(max_missing_ingredients=10)
        user.add_ingredient_suggestions(recipe_results)
        result = user.suggest_ingredient()
        internal_accessor.update_user(user)

        if not result:
            raise NoIngredientError(f"No ingredient suggestions available: "
                                    f"{user.ingredient_suggestions}")
        return result
