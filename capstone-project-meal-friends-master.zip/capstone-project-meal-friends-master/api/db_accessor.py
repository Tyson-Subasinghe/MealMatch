from typing import Dict

from firebase_admin import credentials, db
import firebase_admin

import constants
from logging_tools import log_duration, log_result, LogFormat

"""
We are using Firebase Realtime Database for data persistence.
See here for information about storing data:
 - https://firebase.google.com/docs/database/admin/save-data
Expect a total delay of around 250-500ms for each request.

To access the team database you must do the following:
 - create a Google/Gmail account if you don't have one.
 - send your Google account's email address to the scrum master.
 - sign up to firebase when you receive an invitation.
 - on the firebase website:
   - make sure you see "meal-friends" somewhere on the page. For example:
     https://console.firebase.google.com/project/meal-friends/database/meal-friends/data
   - open the left sidebar.
   - click the cog -> project settings -> service accounts -> click "Generate new private key".
   - save the file inside the project's api/ folder with the filename "private-firebase-credentials.json". 
     This is another private file - don't share the contents. It should automatically be excluded from git.
 - open /api/.env and paste the following line under your existing keys (don't copy the back ticks):
   ```
   ENVIRONMENT=dev
   ```

These functions raise google.auth.exceptions.TransportError on failed database calls
"""

creds = credentials.Certificate("./private-firebase-credentials.json")
firebase_admin.initialize_app(creds, {"databaseURL": "https://meal-friends.firebaseio.com/"})
db_session = db.reference()  # use this for db access


@log_duration
def get_user(uid: str):
    return db_session.child(f"{constants.ENVIRONMENT}/users/{uid}").get()


@log_duration
def update_user(uid: str, user_data: Dict) -> None:
    db_session.child(f"{constants.ENVIRONMENT}/users/{uid}").set(user_data)


@log_duration
@log_result(formatting=LogFormat.SHORT)
def get_user_with_google_id(google_id: str):
    result = (db_session
              .child(f"{constants.ENVIRONMENT}/users")
              .order_by_child("profile/googleId")
              .equal_to(google_id)
              .get())
    if not result:
        return None
    return result


if __name__ == "__main__":
    # For testing this complex function
    print(get_user_with_google_id("<enter a value here>"))
