from typing import Dict

from flask import Flask, request, session
from flask_mail import Mail, Message
import json

import constants
from exceptions import MissingArgError, AuthenticationError, LogoutError, UserError
from logging_tools import log_result
from meal_system import MealSystem
from flask_cors import CORS
from google.oauth2 import id_token
from google.auth.transport import requests

# Set up flask

app = Flask(__name__)
CORS(app, supports_credentials=True)

app.config["DEBUG"] = True
app.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=465,
    MAIL_USE_SSL=True,
    MAIL_USERNAME=constants.GMAIL_USERNAME,
    MAIL_PASSWORD=constants.GMAIL_PASSWORD
)

app.secret_key = constants.FLASK_SESSION_SECRET_KEY
meal_system = MealSystem()


@log_result()
def uid_user_tool(user_session):
    """
    The session object is a cookie that the user sends with each request.
    We can store a long random string in there as a unique user identifier.
    This function ensures that the server is storing data for each client
    who tries to use any of our flask routes.
    We should do this check at the start of each route's logic
    """
    uid = user_session.get("uid", None)
    uid = meal_system.create_user_if_not_exists(uid)
    user_session["uid"] = uid
    return uid


def json_response(response_data) -> json:
    """
    It's good to specify the content-type to ensure the front end knows
    what it's getting.
    Generally we want to jsonify and return 200 as well, so do it all here.
    """
    return json.dumps(response_data), 200, {"Content-Type": "application/json"}


def get_value(pairs: Dict, key, required=True, default=None):
    """
    Handles the common use case of checking a dict for a key,
    then either returning a default or raising an exception.
    """
    try:
        return pairs[key]
    except KeyError:
        if required:
            raise MissingArgError(f"{key} not found in {pairs}")
        else:
            return default


@app.route("/api/user/reset")
def reset_user():
    """
    Now that we have a database, user data will persist.
    Hit this route to clear
    """
    uid = session.get("uid", None)
    if uid:
        meal_system.reset_user(uid)
        return json_response("Cleared user")
    else:
        return json_response("Failed to clear user")


@app.route("/api/user/login", methods=["POST"])
def user_login():
    """
    Logs a user in. Requires an access token in the BODY of the request (not URL),
    as per security recommendations.
    If a user is logging in for the first time, their current session will be
    associated with their login.
    If a user is returning, their current session will be overridden by the saved one.
    Returns the user's details as in the user_details route.
    A similar approach is explained here:
    https://hackingathome.wordpress.com/2020/04/25/everything-you-need-to-know-about-google-sign-in-for-web-apps/

    URL:
        http://127.0.0.1:5000/api/user/login

    Body args (key/value pairs):
        token (str): The user's login access token

    Returns:
        The user's details as in the user_details route

    Raises:
        MissingArgError:
            If no ingredient is specified
        AuthenticationError:
            If the given token does not correctly authorise the user
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    body = request.get_json()
    token = get_value(body, "token")

    id_info = id_token.verify_oauth2_token(token, requests.Request(), constants.GOOGLE_CLIENT_ID)

    google_id = get_value(id_info, "sub")

    aud = get_value(id_info, "aud")
    if aud != constants.GOOGLE_CLIENT_ID:
        raise AuthenticationError(f"Expected aud '{constants.GOOGLE_CLIENT_ID}' but got '{aud}'")

    # name = get_value(id_info, "given_name", required=False, default="friend")
    name = id_info["given_name"]
    email = id_info["email"]
    uid = meal_system.login(uid, google_id, name, email)

    session["uid"] = uid
    return json_response(meal_system.user_to_dict(uid))


@app.route("/api/user/logout")
def user_logout():
    """
    Logs a user out by setting a new flask session.
    The logged-in data should already be safely stored in the database.

    URL:
        http://127.0.0.1:5000/api/user/logout

    Returns:
        The user's details as in the user_details route

    Raises:
        LogoutError:
            If the user has never logged in
        google.auth.exceptions.TransportError:
            If the database call fails
    """
    uid = uid_user_tool(session)
    if not meal_system.is_user_logged_in(uid):
        raise LogoutError(f"User with uid '{uid}' is not logged in and therefore can't log out")

    uid = meal_system.new_user()
    session["uid"] = uid
    return meal_system.user_to_dict(uid)


@app.route("/api/ingredient/search")
def search_ingredient():
    """
    Finds all of the ingredients that include a search string,
    excluding any that the user has already added.
    The `image` field contains the URL for the 500x500 pixel version. More info here:
        https://spoonacular.com/food-api/docs/show-images

    Example URL:
        http://127.0.0.1:5000/api/ingredient/search?ingredient=orange

    URL args:
        ingredient (str): The name of the ingredient to search for

    Returns:
        json (same as the user details route): {
            "ingredients": [
                {"name": ingredient1, "img": "https://.../<something>.jpg"},
                {"name": ingredient2, "img": "https://.../<something>.jpg"},
                ...
            ],
            ...
        }

    Raises:
        requests.exceptions.HTTPError
            If the API call fails
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredient = args.get("ingredient", None)

    ingredients_found = meal_system.user_search_ingredient(uid, ingredient)

    return json_response({"ingredients": ingredients_found.to_dicts(selected_field=False)})


@app.route("/api/ingredient/add")
def add_ingredient():
    """
    Adds an ingredient to the specified user's virtual fridge.
    If no user is specified, assume that the user is a new guest and
    start a new virtual fridge.

    The return value on this route is basically just all the info about a user.
    Hopefully the front end can leverage this to reduce calls to the back end.

    Example URL:
        http://127.0.0.1:5000/api/ingredient/add?ingredient=apple

    URL args:
        ingredient (str): The exact name of the ingredient to add

    Returns:
        json (same as the user details route): {
            "ingredients": [
                {"name": ingredient1, "selected": true, "img": "https://.../<something>.jpg"},
                {"name": ingredient2, "selected": false, "img": "https://.../<something>.jpg"},
                ...
            ],
            ...
        }

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found
        requests.exceptions.HTTPError
            If the API call fails
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)
    args = request.args
    ingredient = args.get("ingredient", None)
    if ingredient is None:
        raise MissingArgError("ingredient")

    meal_system.user_add_ingredient(uid, ingredient)
    user_details = meal_system.user_to_dict(uid)
    return json_response(user_details)


@app.route("/api/ingredient/remove")
def remove_ingredient():
    """
    Removes an ingredient to the specified user's virtual fridge.

    Example URL:
        localhost:5000/api/ingredient/remove?ingredient=apple,egg,chicken

    URL args:
        ingredient (str): One or more comma-separated names of ingredients to remove

    Returns:
        json (same as the user details route): {
            "ingredients": [
                {"name": ingredient1, "selected": true, "img": "https://.../<something>.jpg"},
                {"name": ingredient2, "selected": false, "img": "https://.../<something>.jpg"},
                ...
            ],
            ...
        }

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredients = args.get("ingredient", None)
    if ingredients is None:
        raise MissingArgError("ingredient")

    ingredients = [ingredient for ingredient in ingredients.split(",") if ingredient]

    meal_system.user_remove_ingredients(uid, ingredients)
    user_details = meal_system.user_to_dict(uid)
    return json_response(user_details)


@app.route("/api/ingredient/deselect")
def deselect_ingredient():
    """
    Sets the status of a user's item in their virtual fridge
    to False.
    Returns a summary of the user.
    If the status was already False, nothing will change.
    If the user doesn't have the ingredient in their virtual
    fridge, an exception will be raised.

    Example URL:
        http://127.0.0.1:5000/api/ingredient/deselect?ingredient=egg

    Returns:
        json (same as the user details route): {
            "ingredients": [
                {"name": ingredient1, "selected": true, "img": "https://.../<something>.jpg"},
                {"name": ingredient2, "selected": false, "img": "https://.../<something>.jpg"},
                ...
            ],
            ...
        }

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredient = args.get("ingredient", None)
    if ingredient is None:
        raise MissingArgError("ingredient")

    meal_system.deselect_user_ingredient(uid, ingredient)
    user_details = meal_system.user_to_dict(uid)
    return json_response(user_details)


@app.route("/api/ingredient/select")
def select_ingredient():
    """
    Identical to deselect_ingredient() but sets the selected status to True
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredient = args.get("ingredient", None)
    if ingredient is None:
        raise MissingArgError("ingredient")

    meal_system.select_user_ingredient(uid, ingredient)
    user_details = meal_system.user_to_dict(uid)
    return json_response(user_details)


@app.route("/api/user/details")
def get_user_details():
    """
    This API returns a full json representation of the user, which
    might save some calls to the back end as more features are added.
    Therefore it's named get_user_details instead of get_user_ingredients.

    Example URL:
        http://127.0.0.1:5000/api/user/details

    Returns:
        json: {
            "profile": {
                "googleId" = <google_id or null>,
                "username" = <username>,
                "email"= <gmail>
            },
            "ingredients": [
                {"name": ingredient1, "selected": true, "img": "https://.../<something>.jpg"},
                {"name": ingredient2, "selected": false, "img": "https://.../<something>.jpg"},
                ...
            ],
            "excludedIngredients": [
                {"name": excluded_ingredient1, "img": "https://.../<something>.jpg"},
                {"name": excluded_ingredient2, "img": "https://.../<something>.jpg"},
                ...
            ],
            "shoppingList": [
                {"name": desired_ingredient1, "img": "https://.../<something>.jpg"},
                {"name": desired_ingredient2, "img": "https://.../<something>.jpg"},
                ...
            ],
            "filters" : {
                "diets": [
                    {"name": diet1, "selected": true},
                    {"name": diet2, "selected": false},
                    ...
                ],
                "cuisines": [
                    {"name": cuisine1, "selected": true},
                    {"name": cuisine2, "selected": false},
                    ...
                ],
                "mealTypes": [
                    {"name": meal_type1, "selected": true},
                    {"name": meal_type2, "selected": false},
                    ...
                ]
            }
        }

    Raises:
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)
    user_details = meal_system.user_to_dict(uid)
    return json_response(user_details)


@app.route("/api/recipe/filter/details")
def get_user_filters():
    """
    This API retrieves a representation of all available filters, and their
    selection state for a user.

    Example URL:
        http://127.0.0.1:5000/api/recipe/filter/details

    Returns:
           json: {
            "diets": [
                {"name": diet1, "selected": true},
                {"name": diet2, "selected": false},
                ...
            ],
            "cuisines": [
                {"name": cuisine1, "selected": true},
                {"name": cuisine2, "selected": false},
                ...
            ],
            "mealTypes": [
                {"name": meal_type1, "selected": true},
                {"name": meal_type2, "selected": false},
                ...
            ]
        }

    Raises:
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)
    user_filter_details = meal_system.user_filters_to_dict(uid)
    return json_response(user_filter_details)


@app.route("/api/recipe/filter/deselect")
def deselect_filter():
    """
       Sets the status of a user's filter to false.
       Returns an updated summary of the user's filters.
       If the status was already False, nothing will change.

       Example URL:
           http://127.0.0.1:5000/api/ingredient/deselect?category=diets&name=vegetarian

       Returns:
           json: {
            "diets": [
                {"name": diet1, "selected": true},
                {"name": diet2, "selected": false},
                ...
            ],
            "cuisines": [
                {"name": cuisine1, "selected": true},
                {"name": cuisine2, "selected": false},
                ...
            ],
            "mealTypes": [
                {"name": meal_type1, "selected": true},
                {"name": meal_type2, "selected": false},
                ...
            ]
        }

       Raises:
           MissingArgError
               If no category or filter is specified
            google.auth.exceptions.TransportError:
                If the database call fails

       """

    uid = uid_user_tool(session)

    args = request.args
    category_name = args.get("category", None)
    if category_name is None:
        raise MissingArgError("filter category")
    filter_name = args.get("name", None)
    if filter_name is None:
        raise MissingArgError("filter name")

    meal_system.deselect_user_filter(uid, category_name, filter_name)
    user_filter_details = meal_system.user_filters_to_dict(uid)
    return json_response(user_filter_details)


@app.route("/api/recipe/filter/select")
def select_filter():
    """
    Identical to deselect_filter() but sets the selected status to true

    Example URL:
           http://127.0.0.1:5000/api/ingredient/select?category=diets&name=vegetarian
    """

    uid = uid_user_tool(session)

    args = request.args
    category_name = args.get("category", None)
    if category_name is None:
        raise MissingArgError("filter category")
    filter_name = args.get("name", None)
    if filter_name is None:
        raise MissingArgError("filter name")

    meal_system.select_user_filter(uid, category_name, filter_name)
    user_filter_details = meal_system.user_filters_to_dict(uid)
    return json_response(user_filter_details)


@app.route("/api/recipe/search")
def search_recipe():
    """
    Searches for recipes using all selected ingredients of a user's virtual fridge.
    If there are no ingredients in the fridge, returns an empty list (in json).

    Only recipes with a certain max number of missing ingredients are returned.
    This number is constants.MAX_MISSING_INGREDIENTS in constants.py

    Results are sorted based on arguments "sort" and "order". If no arguments are given,
    it will default to sorting by missedIngredientCount in ascending order.

    "sort" options (same as Spoony field names):
        "missedIngredientCount"
        "usedIngredientCount"
        "readyInMinutes"

    "order" options:
        "ascending"
        "descending"

    Example URL:
        http://127.0.0.1:5000/api/recipe/search?sort=missedIngredientCount&order=ascending

        By default
            http://127.0.0.1:5000/api/recipe/search
        will call
            http://127.0.0.1:5000/api/recipe/search?sort=missedIngredientCount&order=ascending

    Returns:
        json:
        { "recipes" :
            [
                {
                    "id": recipe id,
                    "title": recipe name,
                    "img": image url,
                    "sourceUrl": source url,
                    "readyInMinutes": recipe preparation time,
                    "usedIngredientCount": number of used ingredients,
                    "usedIngredients": [
                        {
                            "name": used ingredient name,
                            "image": used ingredient image
                        }
                    ]
                    "missedIngredientCount": number of missing ingredients,
                    "missedIngredients": [
                        {
                            "name": missing ingredient name,
                            "image": missing ingredient image
                        }
                    ]
                },
                {
                    "id": recipe id 2,pytho
                    "title": recipe name 2,
                    "img": image url 2,
                    "sourceUrl": source url 2,
                    "readyInMinutes": recipe preparation time 2,
                    "usedIngredientCount": number of used ingredients,
                    "usedIngredients": [
                        {
                            "name": used ingredient name,
                            "image": used ingredient image
                        }
                    ]
                    "missedIngredientCount": number of missing ingredients,
                    "missedIngredients": [
                        {
                            "name": missing ingredient 1 name,
                            "image": missing ingredient 1 image
                        },
                        {
                            "name": missing ingredient 2 name,
                            "image": missing ingredient 2 image
                        }
                    ]
                },
                ...
            ]
        }

    Raises:
        requests.exceptions.HTTPError
            If the API call fails
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)
    args = request.args

    sort = args.get("sort", "missedIngredientCount")

    order = args.get("order", None)
    reverse = True if order == "descending" else False

    recipe_search = meal_system.user_search_recipes(uid)
    results = recipe_search.results(max_missing_ingredients=constants.MAX_MISSING_INGREDIENTS, key=sort,
                                    reverse=reverse)

    return json_response({"recipes": results})


@app.route("/api/ingredient/exclude/add")
def exclude_ingredient():
    """
    Excludes a given ingredient from the user's recipe results.
    If the ingredient is already excluded, do nothing.
    If the ingredient exists in another ingredient collection (VF or shopping list),
    the ingredient will first be removed from that existing location.

    Example URL:
        http://127.0.0.1:5000/api/ingredient/exclude/add?ingredient=apple

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found

    Returns:
        The user's details (same as `get_user_details()`)

    Raises:
        MissingArgError
            If no ingredient is specified
        requests.exceptions.HTTPError
            If the API call fails
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredient = args.get("ingredient", None)
    if ingredient is None:
        raise MissingArgError("ingredient")

    meal_system.user_exclude_ingredient(uid, ingredient)
    return json_response(meal_system.user_to_dict(uid))


@app.route("/api/ingredient/exclude/remove")
def remove_excluded_ingredient():
    """
    Removes a given ingredient from the user's excluded ingredients.

    Example URL:
        http://127.0.0.1:5000/api/ingredient/exclude/remove?ingredient=apple

    Returns:
        The user's details (same as `get_user_details()`)

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredient = args.get("ingredient", None)
    if ingredient is None:
        raise MissingArgError("ingredient")

    meal_system.user_remove_excluded_ingredient(uid, ingredient)
    return json_response(meal_system.user_to_dict(uid))


@app.route("/api/ingredient/shopping/add")
def add_to_shopping_list():
    """
    Adds a given ingredient to the user's shopping list.
    If the ingredient exists in another ingredient collection (VF or excluded),
    the ingredient will first be removed from that existing location.

    Example URL:
        http://127.0.0.1:5000/api/ingredient/shopping/add?ingredient=apple

    Returns:
        The user's details (same as `get_user_details()`)

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found
        google.auth.exceptions.TransportError:
            If the database call fails
    """
    uid = uid_user_tool(session)

    args = request.args
    ingredient = get_value(args, "ingredient")

    meal_system.add_to_shopping_list(uid, ingredient)
    return json_response(meal_system.user_to_dict(uid))


@app.route("/api/ingredient/shopping/remove")
def remove_from_shopping_list():
    """
    Removes a given ingredient from the user's shopping list.

    Example URL:
        http://127.0.0.1:5000/api/ingredient/shopping/remove?ingredient=apple

    Returns:
        The user's details (same as `get_user_details()`)

    Raises:
        MissingArgError
            If no ingredient is specified
        NoIngredientError
            If the ingredient can't be found
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    args = request.args
    ingredient = get_value(args, "ingredient")

    meal_system.remove_from_shopping_list(uid, ingredient)
    return json_response(meal_system.user_to_dict(uid))


@app.route("/api/ingredient/suggestion")
def suggest_ingredient():
    """
    Provides a single ingredient suggestion for the user.

    URL:
        http:127.0.0.1:5000/api/ingredient/suggestion

    Returns:
        json {
            "ingredientSuggestion": {
                "name": <name>,
                "img": <https://.../<something>.jpg>
            }
        }

    Raises:
        NoIngredientError:
            If no ingredient suggestion can be provided
        requests.exceptions.HTTPError
            If the API call fails
        google.auth.exceptions.TransportError:
            If the database call fails
    """

    uid = uid_user_tool(session)

    result = meal_system.suggest_ingredient(uid)
    return json_response({"ingredientSuggestion": result.to_dict(selected_field=False)})


@app.route('/api/email/shopping_list')
def send_mail():
    """
        Emails the users shopping list. For this to work, .env must contain
        a valid Gmail email and password e.g.

        GMAIL_USERNAME=mealfriends3900@gmail.com
        GMAIL_PASSWORD=examplePassword123!@#

        URL:
            http:127.0.0.1:5000/api/email/shopping_list

        The Gmail account must have these settings applied:
        https://www.dev2qa.com/how-do-i-enable-less-secure-apps-on-gmail/

        Returns:
            json: {
                "result": "Success"
            }

        Raises:
            google.auth.exceptions.TransportError:
                If the database call fails
            UserError:
                If the user is not logged in
    """

    uid = uid_user_tool(session)

    if meal_system.is_user_logged_in(uid) is None:
        raise UserError("User {uid} is not logged in and cannot send an email")

    user = meal_system.get_user(uid)
    mail = Mail(app)

    msg = Message("Meal Friends Shopping List",
                  sender=constants.GMAIL_USERNAME,
                  recipients=[user.profile.email])

    msg.body = f"Hi {user.profile.username}!\n"
    shopping_list_items = meal_system.get_user(uid).shopping_list.names

    if shopping_list_items:
        # Use " - " before each ingredient name to emulate a list
        shopping_list = "\n".join([f" - {item}" for item in shopping_list_items])
        msg.body += f"Your Shopping List:\n{shopping_list}"
    else:
        msg.body += "Your Shopping List is empty."

    mail.send(msg)
    return json_response({'result': "Success"})
