from typing import Dict, Optional

import constants


class Ingredient:

    def __init__(self, name, image: Optional[str] = None, selected=True):
        self.name = name
        if image:
            # Ingredients from recipes always use 100x100 (too low res)
            image = image.replace("100x100", constants.INGREDIENT_IMAGE_SIZE)
            # Conserve full URLs and convert file names
            if constants.SPOONACULAR_BASE_URL not in image:
                image = f"{constants.INGREDIENT_IMAGE_SIZE_URL}/{image}"
        self.image = image
        self.selected = selected

    def __str__(self):
        return f"{self.name} (selected: {self.selected})"

    def __eq__(self, other):
        # Don't worry about checking whether it's selected.
        # We don't want duplicates of an item with one selected and one not.
        if not isinstance(other, self.__class__):
            return False
        return other.name == self.name

    def __hash__(self):
        # Allows for sets/dicts of Ingredients
        # Assume same name means same image
        return hash(self.name)

    @classmethod
    def from_dict(cls, ingredient_dict):
        name = ingredient_dict.get("name")
        image = ingredient_dict.get("image")
        selected = ingredient_dict.get("selected", True)
        return Ingredient(name, image=image, selected=selected)

    def to_dict(self, selected_field=True) -> Dict:
        return_value = {"name": self.name,
                        "image": self.image,
                        "img": self.image}  # Super terribly hacky. Fulfils F/E request. Sorry.
        if selected_field:
            return_value["selected"] = self.selected
        return return_value

    def deselect(self):
        self.selected = False

    def select(self):
        self.selected = True
